/*
Name: Chen Cheng Yuan
Student ID: 113368513
Date: 2025-12-07
File name: 113368513_week13.cpp
*/

#include "main.h"
#include "queue.h"
#include "space.h"


int main (void)
{
    tQueue *queue;
    int operation;
    tQueueNode *target_node;
    int id, score, ret;
    queue = createQueue();

    while (1)
    {
        printf("Which type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. remove a type 1 item with a specific Id\n");
        printf("4. remove a type 2 item with a specific Id\n");

        scanf("%d", &operation);

        if (operation == 1)
        {
            printf("  enter id and score: ");
            scanf("%d %d", &id, &score);
            ret = enqueue_node(queue, TYPE_SMALL, id, score);
            if (ret == 0)
            {
                printf("    Enqueue Failed !!! \n\n");
                printf("    Cannot enter to the queue\n");
            }
            print_buffer_status();
            print_queue(queue);
            printf("\n");
        }
        else if (operation == 2)
        {
            printf("  enter id and score: ");
            scanf("%d %d", &id, &score);
            ret = enqueue_node(queue, TYPE_LARGE, id, score);
            if (ret == 0)
            {
                printf("    Enqueue Failed !!! \n\n");
                printf("    Cannot enter to the queue\n");
            }
            print_buffer_status();
            print_queue(queue);
            printf("\n");
        }
        else if (operation == 3)
        {
            printf("  enter an ID to remove \n");
            scanf("%d", &id);
            target_node = find_target_node(queue, id, TYPE_SMALL);
            if (target_node != NULL)
            {
                printf("target type: %d, location: %d, id: %d\n", target_node->type + 1, target_node->location, target_node->id);
                if (target_node->next != NULL)
                {
                    printf("target next type: %d, location: %d, id: %d\n", target_node->next->type + 1, target_node->next->location, target_node->next->id);
                }
                dequeue_node(queue, target_node);
            }
            print_buffer_status();
            print_queue(queue);
            printf("\n");
        }
        else if (operation == 4)
        {
            printf("  enter an ID to remove \n");
            scanf("%d", &id);
            target_node = find_target_node(queue, id, TYPE_LARGE);
            if (target_node != NULL)
            {
                printf("target type: %d, location: %d, id: %d\n", target_node->type + 1, target_node->location, target_node->id);
                if (target_node->next != NULL)
                {
                    printf("target next type: %d, location: %d, id: %d\n", target_node->next->type + 1, target_node->next->location, target_node->next->id);
                }
                dequeue_node(queue, target_node);
            }
            print_buffer_status();
            print_queue(queue);
            printf("\n");
        }
    }

}
