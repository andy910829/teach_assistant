#ifndef __QUEUE__
#define __QUEUE__

typedef struct node_info {
    int type;
    int id;
    int location;
    int score;
    struct node_info *next;
    struct node_info *prev;
}tQueueNode;

typedef struct {
    tQueueNode *front;
    tQueueNode *rear;
    int count;
}tQueue;


tQueue* createQueue(void);

int enqueue_node(tQueue *queue, int type, int id, int score);
void dequeue_node(tQueue *queue, tQueueNode *target);
tQueueNode *find_target_node(tQueue *queue, int id, int type);

void print_queue(tQueue *queue);

#endif