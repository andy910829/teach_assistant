#include "queue.h"
#include "space.h"


tQueue* createQueue(void){
    tQueue *queue;
    queue=(tQueue *) malloc (sizeof(tQueue));

    if (queue)
    {
        queue->front=NULL;
        queue->rear=NULL;
        queue->count=0;
    }

    return queue;
}

int enqueue_node(tQueue *queue, int type, int id, int score)
{
    tQueueNode *newptr = NULL;
    int mem_location;

    our_malloc(type, (void **)&newptr, &mem_location);

    if (newptr == NULL)
    {
        return 0;
    }

    newptr->type = type;
    newptr->id = id;
    newptr->score = score;
    newptr->location = mem_location;
    newptr->next = NULL;
    newptr->prev = NULL;

    if (queue->count == 0)
    {
        queue->front = newptr;
        queue->rear = newptr;
    }
    else
    {
        queue->rear->next = newptr;
        newptr->prev = queue->rear;
        queue->rear = newptr;
    }

    queue->count++;

    return 1;
}

void dequeue_node(tQueue *queue, tQueueNode *target)
{
    if (target->prev == NULL && target->next == NULL)
    {
        queue->front = NULL;
        queue->rear = NULL;
    }
    else if (target->prev == NULL)
    {
        queue->front = target->next;
        target->next->prev = NULL;
    }
    else if (target->next == NULL)
    {
        queue->rear = target->prev;
        target->prev->next = NULL;
    }
    else
    {
        target->prev->next = target->next;
        target->next->prev = target->prev;
    }

    queue->count--;
    our_free(target->type, target->location);
}

tQueueNode *find_target_node(tQueue *queue, int id, int type)
{
    int i;
    tQueueNode *target = queue->front;

    for (i = 0; i < queue->count; i++)
    {
        if (target->id == id && target->type == type)
        {
            return target;
        }
        target = target->next;
    }

    return NULL;
}


void print_queue (tQueue *queue)
{
    int i;
    tQueueNode *target = queue->front;

    printf("      type mixed queue: ");
    for (i = 0; i < queue->count; i++)
    {
        printf ("%d,%d(%d,%d) ", target->id, target->score, target->type + 1, target->location);
        target = target->next;
    }
    printf("\n");
}