#include "space.h"

unsigned char buffer[(SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF) + (LARGE_ELEMENT_SIZE * NUM_LARGE_BYTE_BUF)];
unsigned char byte_large_buf_mask[NUM_LARGE_BYTE_BUF] = {0};
unsigned char byte_small_buf_mask[NUM_SMALL_BYTE_BUF] = {0};

void print_buffer_status (void)
{
    int i;

    printf ("      byte_small_buf_mask: ");
    for (i = NUM_SMALL_BYTE_BUF - 1; i >= 0; i--)
    {
        printf ("%d ", byte_small_buf_mask[i]);
    }
    printf ("\n");
    
    printf ("      byte_large_buf_mask: ");
    for (i = NUM_LARGE_BYTE_BUF - 1; i >= 0; i--)
    {
        printf ("%d ", byte_large_buf_mask[i]);
    }
    printf ("\n");
}

void our_malloc(int type, void **target, int *mem_location)
{
    int location;

    location = find_free_space(type);
    if (location < 0)
    {
        return;
    }
    
    set_bits(location, type);
    if (type == TYPE_SMALL)
    {
        *target = (void *)&buffer[location * SMALL_ELEMENT_SIZE];
    }
    else
    {
        *target = (void *)&buffer[LARGE_START + (location - NUM_SMALL_BYTE_BUF) * LARGE_ELEMENT_SIZE];
    }
    *mem_location = location;
}

int find_free_space(int type)
{
    int i;
    
    if (type == TYPE_SMALL)
    {
        // Search for free small buffer
        for (i = 0; i < NUM_SMALL_BYTE_BUF; i++)
        {
            if (byte_small_buf_mask[i] == 0)
            {
                return i;
            }
        }
        // If no small buffer, try large buffer
        for (i = 0; i < NUM_LARGE_BYTE_BUF; i++)
        {
            if (byte_large_buf_mask[i] == 0)
            {
                return NUM_SMALL_BYTE_BUF + i;
            }
        }
    }
    else // TYPE_LARGE
    {
        // Search for free large buffer
        for (i = 0; i < NUM_LARGE_BYTE_BUF; i++)
        {
            if (byte_large_buf_mask[i] == 0)
            {
                return NUM_SMALL_BYTE_BUF + i;
            }
        }
        // If no large buffer, try two consecutive small buffers
        for (i = 0; i < NUM_SMALL_BYTE_BUF - 1; i++)
        {
            if (byte_small_buf_mask[i] == 0 && byte_small_buf_mask[i+1] == 0)
            {
                return i;
            }
        }
    }
    return -1;
}

void set_bits(int location, int type)
{
    if (location < NUM_SMALL_BYTE_BUF)
    {
        // Using small buffer
        if (type == TYPE_SMALL)
        {
            byte_small_buf_mask[location] = 1;
        }
        else // TYPE_LARGE needs 2 small buffers
        {
            byte_small_buf_mask[location] = 1;
            byte_small_buf_mask[location + 1] = 1;
        }
    }
    else
    {
        // Using large buffer
        byte_large_buf_mask[location - NUM_SMALL_BYTE_BUF] = 1;
    }
}

void clear_bits(int location, int type)
{
    if (location < NUM_SMALL_BYTE_BUF)
    {
        // Using small buffer
        if (type == TYPE_SMALL)
        {
            byte_small_buf_mask[location] = 0;
        }
        else // TYPE_LARGE used 2 small buffers
        {
            byte_small_buf_mask[location] = 0;
            byte_small_buf_mask[location + 1] = 0;
        }
    }
    else
    {
        // Using large buffer
        byte_large_buf_mask[location - NUM_SMALL_BYTE_BUF] = 0;
    }
}

void our_free(int type, int mem_location)
{
    clear_bits(mem_location, type);
}

int get_remaining_memory(void)
{
    int i, count = 0;
    for (i = 0; i < NUM_SMALL_BYTE_BUF; i++)
    {
        if (byte_small_buf_mask[i] == 0)
        {
            count++;
        }
    }
    for (i = 0; i < NUM_LARGE_BYTE_BUF; i++)
    {
        if (byte_large_buf_mask[i] == 0)
        {
            count++;
        }
    }
    return count;
}
