#ifndef __QUEUE__
#define __QUEUE__

#include <stdio.h>
#include <stdlib.h>

// 定義資料類型常數
#define TYPE_SMALL 1
#define TYPE_LARGE 2

typedef struct type_small {
    int id;
    int location;
    int score;
} tQueueSmall;

typedef struct type_large {
    int id;
    int location;
    int score[8];
} tQueueLarge;

typedef struct node_info {
    int type;
    void *content;
    struct node_info *next;
    struct node_info *prev;
} tQueueNode;

typedef struct {
    tQueueNode *front;
    tQueueNode *rear;
    int count;
} tQueue;


tQueue* createQueue(void);

// 塞入隊列
int tqueue_enqueue(tQueue *queue, int id, int score, int type);

// 移出隊列
void dequeue_node(tQueue *queue, tQueueNode *target, int type);
// 找到對應的節點
tQueueNode *find_target_node(tQueue *queue, int id, int type);

void print_queue(tQueue *queue);

#endif