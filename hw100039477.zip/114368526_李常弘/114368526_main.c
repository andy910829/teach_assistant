#include "queue.h"
#include "space.h"


int main (void)
{
    tQueue *queue;
    int operation;
    tQueueNode *target_node;
    int id, score=0, ret;
    queue = createQueue();

    while (1)
    {

        printf("\nWhich type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. Remove a type 1 item with a specific Id\n");
        printf("4. Remove a type 2 item with a specific Id\n");
        
        scanf("%d", &operation);
        
        // 新增
        if (operation == 1 || operation == 2)
        {
            printf("  enter id and score: ");
            scanf("%d %d", &id, &score);

            // 塞入隊列
            ret = tqueue_enqueue(queue, id, score, (operation == 1 ? TYPE_SMALL : TYPE_LARGE));
        
            if (ret == 0)
            {
                printf("    Cannot enter to the queue\n");
            }
            print_buffer_status();
        }
        //刪除
        else if (operation == 3 || operation == 4)
        {
            printf ("  enter an ID to remove \n");
            scanf("%d", &id);
            target_node = find_target_node(queue, id, (operation == 3 ? TYPE_SMALL : TYPE_LARGE));
            if (target_node == NULL)
            {
                printf ("    Cannot find the target node \n");
            }
            else
            {
                // 顯示目標節點資訊
                if (operation == 3)
                {
                    tQueueSmall *small_data = (tQueueSmall *)target_node->content;
                    printf("target type: %d, location: %d, id: %d\n", 
                        target_node->type, small_data->location, small_data->id);
                }
                else
                {
                    tQueueLarge *large_data = (tQueueLarge *)target_node->content;
                    printf("target type: %d, location: %d, id: %d\n", 
                        target_node->type, large_data->location, large_data->id);
                }
                
                // 顯示下一個節點資訊（如果存在）
                if (target_node->next != NULL)
                {
                    tQueueNode *next_node = target_node->next;
                    if (next_node->type == TYPE_SMALL)
                    {
                        tQueueSmall *next_data = (tQueueSmall *)next_node->content;
                        printf("target next type: %d, location: %d, id: %d\n", 
                               next_node->type, next_data->location, next_data->id);
                    }
                    else
                    {
                        tQueueLarge *next_data = (tQueueLarge *)next_node->content;
                        printf("target next type: %d, location: %d, id: %d\n", 
                               next_node->type, next_data->location, next_data->id);
                    }
                }
                
                // 移出隊列
                dequeue_node(queue, target_node, (operation == 3 ? TYPE_SMALL : TYPE_LARGE));
            }
            print_buffer_status();

        }
        else 
        {
            printf ("    No such operation \n");   
        }
        print_queue(queue);
    }

}
