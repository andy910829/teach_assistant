#ifndef __SPACE__
#define __SPACE__

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

#define NUM_SMALL_BYTE_BUF      8
#define NUM_LARGE_BYTE_BUF      8

#define ELEMENT_SMALL_SIZE      32
#define ELEMENT_LARGE_SIZE      64
#define LARGE_START             (NUM_SMALL_BYTE_BUF*ELEMENT_SMALL_SIZE)

#define SMALL_FULL              (NUM_SMALL_BYTE_BUF*ELEMENT_SMALL_SIZE)
#define LARGE_FULL              (NUM_LARGE_BYTE_BUF*ELEMENT_LARGE_SIZE)

void print_buffer_status(void);
void our_malloc(int type, void **target, int *mem_location);
void our_free(int type, int mem_location); 

// 檢查是否可以放小檔案
int test_single_location();
// 放置小檔案
void set_single_bit(int location);
void clear_single_bit(int location);

// 檢查是否可以放大檔案（單一位置）
int test_large_location();
// 放置大檔案（單一位置）
void set_large_bit(int location);
void clear_large_bit(int location);

// 檢查是否可以放大檔案（連續兩個位置，保留以防未來需要）
int test_dual_location();
// 放置大檔案（連續兩個位置，保留以防未來需要）
void set_dual_bit(int location);
void clear_dual_bit(int location);

#endif