#include "space.h"

// 總緩衝區：前半部給 small，後半部給 large
unsigned char buffer[SMALL_FULL+LARGE_FULL];
// large 類型的記憶體分配遮罩 (8 個位元)
unsigned char byte_large_buf_mask = 0;
// small 類型的記憶體分配遮罩 (8 個位元)
unsigned char byte_small_buf_mask = 0;

void print_buffer_status (void)
{
    int i;
    unsigned char mask = 0x80;

    // 輸出 small 類型的遮罩狀態
    printf ("      byte_small_buf_mask: ");
    for (i = 0; i< NUM_SMALL_BYTE_BUF; i++)
    {
        printf ("%d ", (byte_small_buf_mask & mask) >> (7-i));
        mask = mask >> 1;
    }
    printf ("\n");
    
    // 輸出 large 類型的遮罩狀態
    mask = 0x80;
    printf ("      byte_large_buf_mask: ");
    for (i = 0; i< NUM_LARGE_BYTE_BUF; i++)
    {
        printf ("%d ", (byte_large_buf_mask & mask) >> (7-i));
        mask = mask >> 1;
    }
    printf ("\n");
}

void our_malloc(int type, void **target, int *mem_location)
{
    int location;

    if (type == TYPE_SMALL)
    // 處理 TYPE_SMALL：優先使用 small buffer，滿了就用 large buffer
    {
        // 先檢查 small_buf_mask 是否有空間
        if (byte_small_buf_mask != 0xFF)
        {
            // 尋找可用的單一位置
            location = test_single_location();
            if (location >= 0) {
                // 設定該位置為已使用
                set_single_bit(location);

                // 計算實際記憶體位置（在 buffer 的前半部）
                *target = (void*)&buffer[location * ELEMENT_SMALL_SIZE];
                *mem_location = location;
                return;
            }
        }
        
        // small_buf_mask 滿了，嘗試使用 large buffer
        if (byte_large_buf_mask != 0xFF)
        {
            location = test_large_location();
            if (location >= 0) {
                set_large_bit(location);
                
                // 計算實際記憶體位置（在 buffer 的後半部）
                *target = (void*)&buffer[LARGE_START + location * ELEMENT_LARGE_SIZE];
                *mem_location = location + NUM_SMALL_BYTE_BUF;  // 加上偏移
                return;
            }
        }
        
        // 兩個 buffer 都滿了
        *target = NULL;
    }
    else if (type == TYPE_LARGE)
    // 處理 TYPE_LARGE：優先使用 large buffer，滿了就用 small buffer
    {
        // 先檢查 large_buf_mask 是否有空間
        if (byte_large_buf_mask != 0xFF)
        {
            // 尋找可用的單一位置
            location = test_large_location();
            if (location >= 0) {
                // 設定該位置為已使用
                set_large_bit(location);

                // 計算實際記憶體位置（在 buffer 的後半部，從 LARGE_START 開始）
                *target = (void*)&buffer[LARGE_START + location * ELEMENT_LARGE_SIZE];
                *mem_location = location;
                return;
            }
        }

        // large_buf_mask 滿了，嘗試使用 small buffer（需要 2 個連續位置）
        location = test_dual_location();
        if (location >= 0) {
            set_dual_bit(location);
            
            // 計算實際記憶體位置（在 buffer 的前半部）
            *target = (void*)&buffer[location * ELEMENT_SMALL_SIZE];
            *mem_location = location;
            return;
        }
        
        // 兩個 buffer 都滿了
        *target = NULL;
    }    
}

int test_single_location()
{
    // 在 small_buf_mask 中尋找下一個可用的位置
    for (int i = 0; i < NUM_SMALL_BYTE_BUF; i++)
    {
        unsigned char mask = 1 << i;
        if ((byte_small_buf_mask & mask) == 0)
        {
            return i;
        }
    }
    return -1;  // 找不到可用位置
}

void set_single_bit(int location)
{
    // 在 small_buf_mask 中設定該位置為已使用
    byte_small_buf_mask |= (1 << location);
}

int test_large_location()
{
    // 在 large_buf_mask 中尋找下一個可用的位置
    for (int i = 0; i < NUM_LARGE_BYTE_BUF; i++)
    {
        unsigned char mask = 1 << i;
        if ((byte_large_buf_mask & mask) == 0)
        {
            return i;
        }
    }
    return -1;  // 找不到可用位置
}

int test_dual_location()
{
    // 在 small_buf_mask 中尋找連續的兩個可用位置(用於 TYPE_LARGE fallback)
    for (int i = 0; i < NUM_SMALL_BYTE_BUF - 1; i++)
    {
        unsigned char m1 = 1 << i;
        unsigned char m2 = 1 << (i + 1);

        // 檢查連續兩個位置是否都是空的
        if ((byte_small_buf_mask & m1) == 0 &&
            (byte_small_buf_mask & m2) == 0)
        {
            return i;
        }
    }
    return -1;  // 找不到連續的兩個可用位置
}

void set_large_bit(int location)
{
    // 在 large_buf_mask 中設定該位置為已使用
    byte_large_buf_mask |= (1 << location);
}

void set_dual_bit(int location)
{
    // 在 small_buf_mask 中設定連續兩個位置為已使用(用於 TYPE_LARGE fallback)
    byte_small_buf_mask |= (1 << location);
    byte_small_buf_mask |= (1 << (location + 1));
}

void clear_single_bit(int location)
{
    // 在 small_buf_mask 中清除該位置(標記為可用)
    byte_small_buf_mask &= ~(1 << location);
}

void clear_large_bit(int location)
{
    // 在 large_buf_mask 中清除該位置(標記為可用)
    byte_large_buf_mask &= ~(1 << location);
}

void clear_dual_bit(int location)
{
    // 在 small_buf_mask 中清除連續兩個位置(標記為可用)(用於 TYPE_LARGE fallback)
    byte_small_buf_mask &= ~(1 << location);
    byte_small_buf_mask &= ~(1 << (location + 1));
}

void our_free(int type, int mem_location)
{
    // 根據 location 判斷資料存在哪個 buffer
    if (mem_location < NUM_SMALL_BYTE_BUF)
    {
        // location 0-7: 在 small buffer 中
        if (type == TYPE_LARGE) {
            // TYPE_LARGE 使用 small buffer 時佔用 2 個連續位置
            clear_dual_bit(mem_location);
        } else {
            // TYPE_SMALL 只佔用 1 個位置
            clear_single_bit(mem_location);
        }
    }
    else
    {
        // location 8-15: 在 large buffer 中
        clear_large_bit(mem_location - NUM_SMALL_BYTE_BUF);
    }
}
