#include "queue.h"
#include "space.h"


tQueue* createQueue(void){    
    tQueue *queue;
    queue=(tQueue *) malloc (sizeof(tQueue));

    if (queue)
    {
        queue->front=NULL;
        queue->rear=NULL;  
        queue->count=0;
    }

    return queue;
}

int tqueue_enqueue(tQueue *queue, int id, int score, int type)
{
    tQueueNode *queue_node;
    void *newptr = NULL;
    int mem_location;

    // 分配隊列節點記憶體
    queue_node = (tQueueNode *)malloc(sizeof(tQueueNode));
    if (queue_node == NULL) {
        printf("    Queue node allocation failed!\n");
        return 0;
    }

    // 根據類型分配對應的資料記憶體
    our_malloc(type, &newptr, &mem_location);

    if (newptr == NULL)
    {
        printf("    Enqueue Failed !!! \n\n");
        free(queue_node);  // 釋放已分配的節點記憶體
        return 0;
    }

    // 根據類型填入資料
    if (type == TYPE_SMALL)
    {
        tQueueSmall *small_data = (tQueueSmall *)newptr;
        small_data->id = id;
        small_data->score = score;
        small_data->location = mem_location;
    }
    else if (type == TYPE_LARGE)
    {
        tQueueLarge *large_data = (tQueueLarge *)newptr;
        large_data->id = id;
        large_data->score[0] = score;  // 將 score 放在陣列第一個位置
        large_data->location = mem_location;
    }

    // 設定隊列節點資訊
    queue_node->type = type;
    queue_node->content = newptr;
    queue_node->next = NULL;
    queue_node->prev = queue->rear;

    // 將節點加入隊列
    if (queue->count == 0)
    {
        queue->front = queue_node;
        queue->rear = queue_node;
    }
    else
    {
        queue->rear->next = queue_node;
        queue->rear = queue_node;
    }

    queue->count++;
    return 1;
}


void dequeue_node(tQueue *queue, tQueueNode *target, int type)
{
    int mem_location;
    
    if (target == NULL) return;

    // 取得記憶體位置資訊
    if (type == TYPE_SMALL)
    {
        tQueueSmall *small_data = (tQueueSmall *)target->content;
        mem_location = small_data->location;
    }
    else if (type == TYPE_LARGE)
    {
        tQueueLarge *large_data = (tQueueLarge *)target->content;
        mem_location = large_data->location;
    }

    // 調整鏈結串列
    if (target->prev)
        target->prev->next = target->next;
    else
        queue->front = target->next;

    if (target->next)
        target->next->prev = target->prev;
    else
        queue->rear = target->prev;

    queue->count--;

    // 釋放資料記憶體占用的 buffer 空間
    our_free(type, mem_location);

    // 釋放隊列節點記憶體
    free(target->content);  // 釋放資料結構
    free(target);           // 釋放節點本身
}

tQueueNode *find_target_node(tQueue *queue, int id, int type)
{
    tQueueNode *target = queue->front;
    
    while (target != NULL)
    {
        // 檢查類型是否符合
        if (target->type == type)
        {
            // 根據類型從 content 中取得 id 進行比對
            if (type == TYPE_SMALL)
            {
                tQueueSmall *small_data = (tQueueSmall *)target->content;
                if (small_data->id == id)
                    return target;
            }
            else if (type == TYPE_LARGE)
            {
                tQueueLarge *large_data = (tQueueLarge *)target->content;
                if (large_data->id == id)
                    return target;
            }
        }
        target = target->next;
    }

    return NULL;
}

void print_queue (tQueue *queue)
{
    int i;
    tQueueNode *target = queue->front;

    printf("      type mixed queue: ");    
    for (i = 0; i < queue->count; i++)
    {
        if (target->type == TYPE_SMALL)
        {
            tQueueSmall *small_data = (tQueueSmall *)target->content;
            printf("%d,%d(%d,%d) ", small_data->id, small_data->score, 
                target->type, small_data->location);
        }
        else if (target->type == TYPE_LARGE)
        {
            tQueueLarge *large_data = (tQueueLarge *)target->content;
            // location 已經根據實際存儲位置設置，直接顯示
            printf("%d,%d(%d,%d) ", large_data->id, large_data->score[0], 
                target->type, large_data->location);
        }
        target = target->next;
    }
    printf("\n");
}