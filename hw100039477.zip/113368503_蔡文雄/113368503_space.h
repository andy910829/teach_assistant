#ifndef __SPACE__
#define __SPACE__

#include "main.h"

#define ELEMENT_SIZE 32 /* 每一個 block 的實際大小（bytes） */

/* 初始化記憶體池與 bitwise 管理結構
 * num_slots: 可以配置的 block 數量（決定 queue 的最大容量）
 */
void init_space(int num_slots);

/* 釋放記憶體池與 bitwise 管理結構 */
void destroy_space(void);

/* 顯示目前 buffer 使用狀態（每個 block 0 or 1） */
void print_buffer_status(void);

/* 只允許用這個 allocator 來配置 tQueueNode */
void our_malloc(int type, void **target, int *mem_location);
void our_free(int type, int mem_location);

#endif