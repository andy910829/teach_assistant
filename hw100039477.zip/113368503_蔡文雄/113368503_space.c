#include "space.h"
#include <string.h> /* for memset */

/* 這裡用 static 全域變數，代表整個程式唯一的一組 memory pool */
static unsigned char *g_buffer = NULL; /* 實際存資料的一大塊空間 */
static unsigned char *g_mask = NULL;   /* bitwise 管理用的 mask 陣列 */
static int g_num_slots = 0;            /* block 數量（queue 容量上限） */
static int g_mask_bytes = 0;           /* mask 陣列長度（bytes） */

/* ---- 內部工具函式：bit 操作 ---- */

/* 回傳某個 location 是否已被占用（1=占用, 0=空閒） */
static int is_bit_set(int location)
{
    int byte_index, bit_index;

    if (location < 0 || location >= g_num_slots || g_mask == NULL)
        return 0;

    byte_index = location / 8;
    bit_index = location % 8;

    return (g_mask[byte_index] & (1 << bit_index)) != 0;
}

/* 把某個 location 對應的 bit 設為 1（代表 block 被占用） */
static void set_bit(int location)
{
    int byte_index, bit_index;

    if (location < 0 || location >= g_num_slots || g_mask == NULL)
        return;

    byte_index = location / 8;
    bit_index = location % 8;

    g_mask[byte_index] |= (1 << bit_index);
}

/* 把某個 location 對應的 bit 清為 0（代表 block 空閒） */
static void clear_bit(int location)
{
    int byte_index, bit_index;

    if (location < 0 || location >= g_num_slots || g_mask == NULL)
        return;

    byte_index = location / 8;
    bit_index = location % 8;

    g_mask[byte_index] &= ~(1 << bit_index);
}

/* ---- 對外的 API ---- */

/* 初始化記憶體池與 bitwise 管理結構
 * num_slots: 可以配置的 block 數量（決定 queue 的最大容量）
 */
void init_space(int num_slots)
{
    if (num_slots <= 0)
        num_slots = 8; /* 給個保底值，避免輸入 <= 0 */

    g_num_slots = num_slots;
    g_mask_bytes = (g_num_slots + 7) / 8; /* 無條件進位 */

    /* ====== 這裡用掉 2 次 malloc（data buffer + bit mask）====== */
    g_buffer = (unsigned char *)malloc(ELEMENT_SIZE * g_num_slots);
    g_mask = (unsigned char *)malloc(g_mask_bytes);

    if (g_buffer == NULL || g_mask == NULL)
    {
        printf("Init space failed: cannot allocate memory pool.\n");
        exit(1);
    }

    /* 一開始所有 block 都是空的（mask 全部清成 0） */
    memset(g_buffer, 0, ELEMENT_SIZE * g_num_slots);
    memset(g_mask, 0, g_mask_bytes);
}

/* 釋放記憶體池與 bitwise 管理結構 */
void destroy_space(void)
{
    if (g_buffer != NULL)
    {
        free(g_buffer);
        g_buffer = NULL;
    }

    if (g_mask != NULL)
    {
        free(g_mask);
        g_mask = NULL;
    }

    g_num_slots = 0;
    g_mask_bytes = 0;
}

/* 顯示目前 buffer 使用狀態（每個 block 0 or 1） */
void print_buffer_status(void)
{
    int i;

    printf("      buffer status: ");
    for (i = 0; i < g_num_slots; i++)
    {
        printf("%d ", is_bit_set(i) ? 1 : 0);
    }
    printf("\n");
}

/* our_malloc:
 *  - type = TYPE_SMALL: 找一個空 block
 *  - type = TYPE_LARGE: 找兩個連續的空 block
 *  - 透過 void** target 回傳實際可用位址
 *  - 透過 *mem_location 回傳起始的 block index
 */
void our_malloc(int type, void **target, int *mem_location)
{
    int i;

    if (target == NULL || mem_location == NULL)
        return;

    *target = NULL;
    *mem_location = -1;

    if (g_buffer == NULL || g_mask == NULL || g_num_slots <= 0)
        return;

    if (type == TYPE_SMALL)
    {
        for (i = 0; i < g_num_slots; i++)
        {
            if (!is_bit_set(i))
            {
                set_bit(i);
                *mem_location = i;
                *target = (void *)(g_buffer + (i * ELEMENT_SIZE));
                return;
            }
        }
    }
    else if (type == TYPE_LARGE)
    {
        for (i = 0; i < g_num_slots - 1; i++)
        {
            if (!is_bit_set(i) && !is_bit_set(i + 1))
            {
                set_bit(i);
                set_bit(i + 1);
                *mem_location = i;
                *target = (void *)(g_buffer + (i * ELEMENT_SIZE));
                return;
            }
        }
    }

    /* 沒有足夠空間 */
    *target = NULL;
    *mem_location = -1;
}

/* our_free:
 *  - 把對應 block 的 bit 清成 0
 *  - large item 會清兩格
 */
void our_free(int type, int mem_location)
{
    if (mem_location < 0 || mem_location >= g_num_slots)
        return;

    if (type == TYPE_SMALL)
    {
        clear_bit(mem_location);
    }
    else if (type == TYPE_LARGE)
    {
        clear_bit(mem_location);
        if (mem_location + 1 < g_num_slots)
            clear_bit(mem_location + 1);
    }
}