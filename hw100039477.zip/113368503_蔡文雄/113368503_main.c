#include "main.h"
#include "queue.h"
#include "space.h"

int main(void)
{
    tQueue *queue;
    int operation;
    tQueueNode *target_node;
    int id, score = 0, ret;
    int num_slots;

    /* 先決定 memory pool 的大小（queue 容量） */
    printf("Enter number of memory blocks for the queue: ");
    if (scanf("%d", &num_slots) != 1 || num_slots <= 0)
    {
        printf("Invalid input. Use default 8 blocks.\n");
        num_slots = 8;
    }

    /* 初始化通用記憶體池（small / big 都共用這一塊） */
    init_space(num_slots);

    /* 建立「通用 queue」
       Week13：createQueue() 裡面不再使用 malloc，而是回傳 static 物件 */
    queue = createQueue();
    if (queue == NULL)
    {
        printf("Cannot create queue.\n");
        destroy_space();
        return 1;
    }

    while (1)
    {
        printf("\n");
        printf("1. Add a small item\n");
        printf("2. Add a big item\n");
        printf("3. Remove a small item with a specific Id\n");
        printf("4. Remove a big item with a specific Id\n");
        printf("0. Exit\n");
        printf("Select operation: ");

        if (scanf("%d", &operation) != 1)
        {
            printf("Invalid input.\n");
            break;
        }

        if (operation == 0)
        {
            /* 結束程式 */
            break;
        }
        else if (operation == 1 || operation == 2)
        {
            printf("  Enter id: ");
            if (scanf("%d", &id) != 1)
            {
                printf("Invalid id.\n");
                break;
            }

            ret = enqueue_node(
                queue,
                id,
                score,
                (operation == 1 ? TYPE_SMALL : TYPE_LARGE));

            if (ret == 0)
            {
                printf("    Cannot enter to the queue\n");
            }

            /* 顯示記憶體池使用狀態（bitmask） */
            print_buffer_status();
        }
        else if (operation == 3 || operation == 4)
        {
            printf("  Enter an ID to remove ");
            if (scanf("%d", &id) != 1)
            {
                printf("Invalid id.\n");
                break;
            }

            target_node = find_target_node(
                queue,
                id,
                (operation == 3 ? TYPE_SMALL : TYPE_LARGE));

            if (target_node == NULL)
            {
                printf("    Cannot find the target node \n");
            }
            else
            {
                dequeue_node(
                    queue,
                    target_node,
                    (operation == 3 ? TYPE_SMALL : TYPE_LARGE));
            }
        }
        else
        {
            printf("    No such operation \n");
        }

        /* 印出目前 queue 內容（同一條 queue，s / b 混在一起） */
        print_queue(queue);
    }

    /* 收尾：釋放「通用記憶體池」 */
    destroy_space();

    return 0;
}