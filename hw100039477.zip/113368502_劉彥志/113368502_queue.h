#ifndef __QUEUE__
#define __QUEUE__

#include "main.h"
#include "space.h"

/* payload 型別（真正放在 buffer 的資料） */
typedef struct
{
    int id;
    int location; /* 小：0..7；大：8..15 */
    int score;
} tQueueSmall;

typedef struct
{
    int id;
    int location; /* 8..15 */
    int score[8]; /* 範例只印 score[0]，其餘保留 */
} tQueueLarge;

/* 節點用 void* 指向 payload */
typedef struct node_info
{
    int type;      /* TYPE_SMALL / TYPE_LARGE */
    void *content; /* 指向 tQueueSmall 或 tQueueLarge */
    struct node_info *next;
    struct node_info *prev;
} tQueueNode;

typedef struct
{
    tQueueNode *front;
    tQueueNode *rear;
    int count;
} tQueue;

/* 介面 */
tQueue *createQueue(void);
int tqueue_enqueue(tQueue *queue, int id, int score, int type);
tQueueNode *tqueue_find_by_id(tQueue *queue, int id, int type);
void tqueue_remove_node(tQueue *queue, tQueueNode *target);
void print_queue(tQueue *queue);

#endif
