#ifndef __SPACE__
#define __SPACE__

#include "main.h"

/* 小/大緩衝各 8 格 */
#define NUM_SMALL_BYTE_BUF 8
#define NUM_LARGE_BYTE_BUF 8

#define SMALL_ELEMENT_SIZE 32
#define LARGE_ELEMENT_SIZE 64

/* 大塊在整體 buffer 的起始位移 */
#define LARGE_START (SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF)

/* 介面 */
void print_buffer_status(void);
int our_malloc(int type, void **target, int *location /*印用*/);
void our_free(int type, int location);
#endif
