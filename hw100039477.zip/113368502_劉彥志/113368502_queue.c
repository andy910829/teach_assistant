#include "queue.h"

/* 只允許兩次 malloc：這裡不再動態配置節點，改用靜態 node pool */
#define MAX_NODES (NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)

static tQueueNode g_node_pool[MAX_NODES];
static unsigned char g_node_used[MAX_NODES] = {0};

static tQueueNode *alloc_node(void)
{
    for (int i = 0; i < MAX_NODES; ++i)
    {
        if (!g_node_used[i])
        {
            g_node_used[i] = 1;
            g_node_pool[i].next = g_node_pool[i].prev = NULL;
            g_node_pool[i].content = NULL;
            g_node_pool[i].type = 0;
            return &g_node_pool[i];
        }
    }
    return NULL;
}

static void free_node(tQueueNode *p)
{
    if (!p)
        return;
    int idx = (int)(p - g_node_pool);
    if (idx >= 0 && idx < MAX_NODES)
        g_node_used[idx] = 0;
}

tQueue *createQueue(void)
{
    /* malloc #1：僅配置 queue 頭 */
    tQueue *q = (tQueue *)malloc(sizeof(tQueue));
    if (q)
    {
        q->front = q->rear = NULL;
        q->count = 0;
    }
    return q;
}

int tqueue_enqueue(tQueue *queue, int id, int score, int type)
{
    void *payload = NULL;
    int loc = -1;

    /* 向小池/大池拿一格（payload 放在靜態 buffer 裡） */
    if (!our_malloc(type, &payload, &loc))
    {
        printf("    Enqueue Failed !!! \n\n");
        return 0;
    }

    /* 取一顆節點（靜態 pool） */
    tQueueNode *node = alloc_node();
    if (!node)
    {
        /* 還原剛剛拿到的 buffer */
        our_free(type, loc);
        printf("    Enqueue Failed !!! \n\n");
        return 0;
    }

    node->type = type;
    node->content = payload;

    if (type == TYPE_SMALL)
    {
        tQueueSmall *s = (tQueueSmall *)payload;
        s->id = id;
        s->location = loc; /* 0..7 */
        s->score = score;
    }
    else
    {
        tQueueLarge *l = (tQueueLarge *)payload;
        l->id = id;
        l->location = loc; /* 8..15 */
        for (int i = 0; i < 8; ++i)
            l->score[i] = 0;
        l->score[0] = score;
    }

    /* 尾插 */
    if (queue->count == 0)
    {
        queue->front = queue->rear = node;
    }
    else
    {
        node->prev = queue->rear;
        queue->rear->next = node;
        queue->rear = node;
    }
    queue->count++;
    return 1;
}

tQueueNode *tqueue_find_by_id(tQueue *queue, int id, int type)
{
    for (tQueueNode *p = queue->front; p; p = p->next)
    {
        if (p->type != type)
            continue;
        if (type == TYPE_SMALL)
        {
            tQueueSmall *s = (tQueueSmall *)p->content;
            if (s->id == id)
                return p;
        }
        else
        {
            tQueueLarge *l = (tQueueLarge *)p->content;
            if (l->id == id)
                return p;
        }
    }
    return NULL;
}

void tqueue_remove_node(tQueue *queue, tQueueNode *target)
{
    if (!queue || !target)
        return;

    /* debug 輸出（符合範例） */
    if (target->type == TYPE_SMALL)
    {
        tQueueSmall *s = (tQueueSmall *)target->content;
        printf("target type: 1, location: %d, id: %d\n", s->location, s->id);
        if (target->next)
        {
            if (target->next->type == TYPE_SMALL)
            {
                tQueueSmall *ns = (tQueueSmall *)target->next->content;
                printf("target next type: 1, location: %d, id: %d\n", ns->location, ns->id);
            }
            else
            {
                tQueueLarge *nl = (tQueueLarge *)target->next->content;
                printf("target next type: 2, location: %d, id: %d\n", nl->location, nl->id);
            }
        }
        our_free(TYPE_SMALL, s->location);
    }
    else
    {
        tQueueLarge *l = (tQueueLarge *)target->content;
        printf("target type: 2, location: %d, id: %d\n", l->location, l->id);
        if (target->next)
        {
            if (target->next->type == TYPE_SMALL)
            {
                tQueueSmall *ns = (tQueueSmall *)target->next->content;
                printf("target next type: 1, location: %d, id: %d\n", ns->location, ns->id);
            }
            else
            {
                tQueueLarge *nl = (tQueueLarge *)target->next->content;
                printf("target next type: 2, location: %d, id: %d\n", nl->location, nl->id);
            }
        }
        our_free(TYPE_LARGE, l->location);
    }

    /* 從鏈結中卸下 */
    if (target->prev)
        target->prev->next = target->next;
    else
        queue->front = target->next;

    if (target->next)
        target->next->prev = target->prev;
    else
        queue->rear = target->prev;

    queue->count--;
    free_node(target);
}

void print_queue(tQueue *queue)
{
    printf("      type mixed queue: ");
    for (tQueueNode *p = queue->front; p; p = p->next)
    {
        if (p->type == TYPE_SMALL)
        {
            tQueueSmall *s = (tQueueSmall *)p->content;
            printf("%d,%d(1,%d) ", s->id, s->score, s->location);
        }
        else
        {
            tQueueLarge *l = (tQueueLarge *)p->content;
            printf("%d,%d(2,%d) ", l->id, l->score[0], l->location);
        }
    }
    printf("\n");
}
