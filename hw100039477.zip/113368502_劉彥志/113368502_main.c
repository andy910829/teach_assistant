#include "main.h"
#include "queue.h"
#include "space.h"

int main(void)
{
    /* malloc #1：queue head */
    tQueue *queue = createQueue();

    int op, id, score;

    while (1)
    {
        printf("Which type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. remove a type 1 item with a specific Id\n");
        printf("4. remove a type 2 item with a specific Id\n");

        if (scanf("%d", &op) != 1)
            break;

        if (op == 1 || op == 2)
        {
            printf("  enter id and score: ");
            if (scanf("%d %d", &id, &score) != 2)
                break;

            if (!tqueue_enqueue(queue, id, score, (op == 1 ? TYPE_SMALL : TYPE_LARGE)))
            {
                printf("\n    Cannot enter to the queue\n");
            }
            print_buffer_status();
        }
        else if (op == 3 || op == 4)
        {
            printf("  enter an ID to remove \n");
            if (scanf("%d", &id) != 1)
                break;

            tQueueNode *t = tqueue_find_by_id(queue, id, (op == 3 ? TYPE_SMALL : TYPE_LARGE));
            if (!t)
            {
                printf("    cannot find the target node \n");
            }
            else
            {
                tqueue_remove_node(queue, t);
            }
            print_buffer_status();
        }
        else
        {
            printf("    No such operation \n");
        }
        print_queue(queue);
    }
    return 0;
}
