#include "space.h"

/* 兩個池的實體儲存空間（靜態，非 malloc） */
static unsigned char buffer[SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF +
                            LARGE_ELEMENT_SIZE * NUM_LARGE_BYTE_BUF];

/* 兩個池的位元遮罩：1=已用、0=空閒。bit7 是最左邊（MSB） */
static unsigned char byte_small_buf_mask = 0;
static unsigned char byte_large_buf_mask = 0;

/* 以 MSB→LSB 的順序輸出（與老師範例一致） */
static void print_mask_line(const char *title, unsigned char mask)
{
    int i;
    printf("      %s: ", title);
    for (i = 7; i >= 0; --i)
    {
        printf("%d ", (mask >> i) & 1);
    }
    printf("\n");
}

void print_buffer_status(void)
{
    print_mask_line("byte_small_buf_mask", byte_small_buf_mask);
    print_mask_line("byte_large_buf_mask", byte_large_buf_mask);
}

// 從 LSB → MSB 找第一個 0
static int first_zero_bit(unsigned char mask)
{
    for (int i = 0; i <= 7; ++i)
    {
        if (((mask >> i) & 1) == 0)
            return i; // i=0 代表最右邊那格
    }
    return -1;
}

// 位元位置 = 槽索引（LSB=0 -> 索引0）
static int bitpos_to_index(int bitpos)
{
    return bitpos;
}

/* our_malloc：回傳 1 成功，0 失敗。*location 供印出（小：0..7；大：8..15） */
int our_malloc(int type, void **target, int *location)
{
    *target = NULL;

    if (type == TYPE_SMALL)
    {
        // 從 small 池找空位（LSB→MSB）
        int bitpos = first_zero_bit(byte_small_buf_mask);
        if (bitpos < 0)
            return 0;
        byte_small_buf_mask |= (unsigned char)(1u << bitpos);

        int idx = bitpos; // 0..7
        *target = (void *)(buffer + /* SMALL_START = 0 */ idx * SMALL_ELEMENT_SIZE);
        if (location)
            *location = idx; // 小塊位置 0..7
        return 1;
    }
    else if (type == TYPE_LARGE)
    {
        // 從 large 池找空位（LSB→MSB）
        int bitpos = first_zero_bit(byte_large_buf_mask);
        if (bitpos < 0)
            return 0;
        byte_large_buf_mask |= (unsigned char)(1u << bitpos);

        int idx = bitpos; // 0..7
        *target = (void *)(buffer + LARGE_START + idx * LARGE_ELEMENT_SIZE);
        if (location)
            *location = 8 + idx; // 大塊位置 8..15
        return 1;
    }
    return 0;
}

void our_free(int type, int location)
{
    if (type == TYPE_SMALL)
    {
        if (location < 0 || location > 7)
            return;
        int bitpos = location; // 直接等於 location
        byte_small_buf_mask &= (unsigned char)~(1u << bitpos);
    }
    else if (type == TYPE_LARGE)
    {
        int idx = location - 8; // 8..15 -> 0..7
        if (idx < 0 || idx > 7)
            return;
        int bitpos = idx;
        byte_large_buf_mask &= (unsigned char)~(1u << bitpos);
    }
}
