#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>
#include <stdlib.h>

#define TYPE_SMALL 1
#define TYPE_LARGE 2

#endif
