#include "main.h"
#include "queue.h"
#include "space.h"

void print_node_info(tQueueNode *node, const char *prefix) {
    if (!node) return;
    int id, loc;
    if (node->type == 1) {
        tQueueSmall *s = (tQueueSmall*)node->content;
        id = s->id; loc = s->location;
    } else {
        tQueueLarge *l = (tQueueLarge*)node->content;
        id = l->id; loc = l->location;
    }
    printf("%s type: %d, location: %d, id: %d\n", prefix, node->type, loc, id);
}

int main(void) {
    tQueue *queue = createQueue();
    init_buffer_management();

    while (1) {
        int operation;
        printf("\nWhich type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. remove a type 1 item with a specific Id\n");
        printf("4. remove a type 2 item with a specific Id\n");

        if (scanf("%d", &operation) != 1) {
            int c; 
            while ((c = getchar()) != '\n' && c != EOF);
            printf("    Invalid input\n");
            continue;
        }

        if (operation == 1 || operation == 2) {
            int id, score;
            printf("  enter id and score: ");
            if (scanf("%d %d", &id, &score) != 2) 
                continue;

            int type = (operation == 1) ? 1 : 2;
            enqueue_node(queue, type, id, score);
            
            print_buffer_status();
            print_queue(queue);
        }
        else if (operation == 3 || operation == 4) {
            int id;
            printf("  enter an ID to remove \n");
            if (scanf("%d", &id) != 1) 
                continue;

            int target_type = (operation == 3) ? 1 : 2;
            tQueueNode *node = find_target_node(queue, id, target_type);

            if (!node) {
                printf("    cannot find the target node \n");
            } else {
                print_node_info(node, "target");
                if (node->next) {
                    print_node_info(node->next, "target next");
                }
                dequeue_node(queue, node);
            }
            print_buffer_status();
            print_queue(queue);
        }
        else {
            printf("    No such operation \n");
        }
    }

    return 0;
}