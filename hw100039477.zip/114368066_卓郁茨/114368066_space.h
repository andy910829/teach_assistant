#ifndef _SPACE_
#define _SPACE_

#include "main.h"

#define NUM_SMALL_BYTE_BUF  8
#define NUM_LARGE_BYTE_BUF  8

#define SMALL_ELEMENT_SIZE  32
#define LARGE_ELEMENT_SIZE  64

// Large 區塊在 Buffer 中的起始位置 (接在 Small 之後)
#define LARGE_START         (SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF)

void init_buffer_management(void);
void print_buffer_status(void);

// 修改：增加 type 參數，移除 units (因為大小固定)
void our_malloc(int type, void **target, int *mem_location);
void our_free(int type, int mem_location);

#endif