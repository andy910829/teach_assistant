#include <stdio.h>    
#include <stdlib.h>   
#include <stddef.h> 
#include "queue.h"
#include "space.h"

tQueue* createQueue(void) {
    tQueue *queue = (tQueue*) malloc(sizeof(tQueue));
    if (queue) {
        queue->front = queue->rear = NULL;
        queue->count = 0;
    }
    return queue;
}

int enqueue_node(tQueue *queue, int type, int id, int score) {
    tQueueNode *node = NULL;
    void *data_ptr = NULL;
    int mem_location = -1;

    our_malloc(type, &data_ptr, &mem_location);
    
    if (data_ptr == NULL) {
        printf("    Enqueue Failed !!! \n\n");
        printf("    Cannot enter to the queue\n");
        return 0;
    }

    // 只能使用兩個 malloc，這是其中之一
    node = (tQueueNode*) malloc(sizeof(tQueueNode));
    if (!node) return 0;

    // 根據 type 轉型並填寫資料
    if (type == 1) {
        tQueueSmall *small = (tQueueSmall*) data_ptr;
        small->id = id;
        small->score = score;
        small->location = mem_location;
    } else {
        tQueueLarge *large = (tQueueLarge*) data_ptr;
        large->id = id;
        large->score[0] = score; 
        large->location = mem_location;
    }

    node->type = type;
    node->content = data_ptr;
    node->next = NULL;
    node->prev = NULL;

    if (!queue->rear) {
        queue->front = queue->rear = node;
    } else {
        queue->rear->next = node;
        node->prev = queue->rear;
        queue->rear = node;
    }
    queue->count++;
    return 1;
}

void dequeue_node(tQueue *queue, tQueueNode *target) {
    if (!queue || !target) 
        return;

    if (target->prev) 
        target->prev->next = target->next;
    else 
        queue->front = target->next;

    if (target->next) 
        target->next->prev = target->prev;
    else 
        queue->rear = target->prev;

    queue->count--;

    // 取出 location 用於釋放
    int loc = -1;
    if (target->type == 1) {
        loc = ((tQueueSmall*)target->content)->location;
    } else {
        loc = ((tQueueLarge*)target->content)->location;
    }

    // 呼叫 space.c 的釋放
    our_free(target->type, loc);
    free(target);
}

tQueueNode *find_target_node(tQueue *queue, int id, int type) {
    tQueueNode *node = queue->front;
    while (node) {
        int current_id = -1;
        if (node->type == 1) 
            current_id = ((tQueueSmall*)node->content)->id;
        else 
            current_id = ((tQueueLarge*)node->content)->id;

        if (current_id == id && node->type == type) 
            return node;
        node = node->next;
    }
    return NULL;
}

void print_queue(tQueue *queue) {
    tQueueNode *node = queue->front;
    printf("      type mixed queue: ");
    while (node) {
        int id, score, loc;
        // 讀取資料
        if (node->type == 1) {
            tQueueSmall *s = (tQueueSmall*)node->content;
            id = s->id; score = s->score; loc = s->location;
        } else {
            tQueueLarge *l = (tQueueLarge*)node->content;
            id = l->id; score = l->score[0]; loc = l->location;
        }
        
        // 列印格式：id,score(type,location)
        // 這裡會正確顯示 (2,5)，因為 Type 是 2，但 location 是從 Small Buffer 借來的 5
        printf("%d,%d(%d,%d) ", id, score, node->type, loc);
        node = node->next;
    }
    printf("\n");
}