#include "space.h"
#include <string.h>
#include <stdio.h>

unsigned char buffer[SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF + LARGE_ELEMENT_SIZE * NUM_LARGE_BYTE_BUF];
unsigned char byte_small_buf_mask = 0;
unsigned char byte_large_buf_mask = 0;

void init_buffer_management(void) {
    byte_small_buf_mask = 0;
    byte_large_buf_mask = 0;
    memset(buffer, 0, sizeof(buffer));
}

// 找空位 (0-7)
int find_available_index(unsigned char mask) {
    for (int i = 0; i < 8; i++) {
        if (((mask >> i) & 0x01) == 0) {
            return i;
        }
    }
    return -1;
}

// 依照 Demo 格式印出 Binary (High bit -> Low bit)
void print_mask(unsigned char mask) {
    for (int i = 7; i >= 0; i--) {
        printf("%d", (mask >> i) & 0x01);
        if (i > 0) printf(" ");
    }
}

void print_buffer_status(void) {
    printf("      byte_small_buf_mask: ");
    print_mask(byte_small_buf_mask);
    printf("\n");
    
    printf("      byte_large_buf_mask: ");
    print_mask(byte_large_buf_mask);
    printf("\n");
}

void our_malloc(int type, void **target, int *mem_location) {
    int index = -1;

    if (type == 1) {
        // Type 1 只能用 Small 區
        index = find_available_index(byte_small_buf_mask);
        if (index != -1) {
            byte_small_buf_mask |= (1 << index);
            *target = &buffer[index * SMALL_ELEMENT_SIZE];
            *mem_location = index; // 0-7
        } else {
            *target = NULL;
            *mem_location = -1;
        }
    } 
    else if (type == 2) {
        // Type 2 優先使用 Large 區
        index = find_available_index(byte_large_buf_mask);
        if (index != -1) {
            byte_large_buf_mask |= (1 << index);
            *target = &buffer[LARGE_START + (index * LARGE_ELEMENT_SIZE)];
            *mem_location = index + NUM_SMALL_BYTE_BUF; // 回傳 8-15 以便識別
        } 
        else {
            //如果 Large 滿了，嘗試借用 Small 區
            index = find_available_index(byte_small_buf_mask);
            if (index != -1) {
                byte_small_buf_mask |= (1 << index);
                
                *target = &buffer[index * SMALL_ELEMENT_SIZE]; 
                *mem_location = index; // 回傳 0-7，這樣就會顯示 (2,5)
            } else {
                *target = NULL;
                *mem_location = -1;
            }
        }
    }
}

void our_free(int type, int mem_location) {
    //釋放時不看 type，而是看 location 到底在哪一區
    if (mem_location >= 0 && mem_location < NUM_SMALL_BYTE_BUF) {
        // 落入 Small 區 (0-7)
        byte_small_buf_mask &= ~(1 << mem_location);
        memset(&buffer[mem_location * SMALL_ELEMENT_SIZE], 0, SMALL_ELEMENT_SIZE);
    } 
    else if (mem_location >= NUM_SMALL_BYTE_BUF && mem_location < (NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)) {
        // 落入 Large 區 (8-15)
        int idx = mem_location - NUM_SMALL_BYTE_BUF;
        byte_large_buf_mask &= ~(1 << idx);
        memset(&buffer[LARGE_START + (idx * LARGE_ELEMENT_SIZE)], 0, LARGE_ELEMENT_SIZE);
    }
}