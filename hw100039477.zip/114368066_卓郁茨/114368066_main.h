#ifndef _MAIN_
#define _MAIN_
#include <stdio.h>
#include <stdlib.h>
#endif