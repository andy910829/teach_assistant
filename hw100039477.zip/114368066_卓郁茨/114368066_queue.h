#ifndef _QUEUE_
#define _QUEUE_

typedef struct type_small {
    int id;
    int location;
    int score;
} tQueueSmall;

typedef struct type_large {
    int id;
    int location;
    int score[8]; // Array for large
} tQueueLarge;

// 通用節點
typedef struct node_info {
    int type;           // 1 or 2
    void *content;      // 指向 Buffer 中的 tQueueSmall 或 tQueueLarge
    struct node_info *next;
    struct node_info *prev;
} tQueueNode;

typedef struct {
    tQueueNode *front;
    tQueueNode *rear;
    int count;
} tQueue;

tQueue* createQueue(void);
int enqueue_node(tQueue *queue, int type, int id, int score);
void dequeue_node(tQueue *queue, tQueueNode *target);
tQueueNode *find_target_node(tQueue *queue, int id, int type); // 增加 type 以區分
void print_queue(tQueue *queue);

#endif