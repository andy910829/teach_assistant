#include "main.h"
#include "space.h"

unsigned char buffer[SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF + LARGE_ELEMENT_SIZE * NUM_LARGE_BYTE_BUF];

unsigned char byte_small_buf_mask = 0;
unsigned char byte_large_buf_mask = 0;

void print_buffer_status (void)
{
    int i;
    unsigned char mask;

    printf ("      byte_small_buf_mask: ");
    mask = 0x80;
    for (i = 0; i< NUM_SMALL_BYTE_BUF; i++)
    {
        printf ("%d ", (byte_small_buf_mask & mask) ? 1 : 0);
        mask = mask >> 1;
    }
    printf ("\n");

    printf ("      byte_large_buf_mask: ");
    mask = 0x80;
    for (i = 0; i< NUM_LARGE_BYTE_BUF; i++)
    {
        printf ("%d ", (byte_large_buf_mask & mask) ? 1 : 0);
        mask = mask >> 1;
    }
    printf ("\n");
}

void our_malloc(int type, void **target, int *mem_location)
{
    int location;

    *target = NULL;
    *mem_location = -1;

    if (type == TYPE_SMALL)
    {
        location = test_single_location(byte_small_buf_mask, NUM_SMALL_BYTE_BUF);
        if (location >= 0)
        {
            set_single_bit(&byte_small_buf_mask, location);
            *target = (void *)&buffer[SMALL_ELEMENT_SIZE * location];
            *mem_location = location;
            return;
        }

        location = test_single_location(byte_large_buf_mask, NUM_LARGE_BYTE_BUF);
        if (location >= 0)
        {
            set_single_bit(&byte_large_buf_mask, location);
            *target = (void *)&buffer[LARGE_START + LARGE_ELEMENT_SIZE * location];
            *mem_location = NUM_SMALL_BYTE_BUF + location;
            return;
        }

        return;
    }
    else /* TYPE_LARGE */
    {
        location = test_single_location(byte_large_buf_mask, NUM_LARGE_BYTE_BUF);
        if (location >= 0)
        {
            set_single_bit(&byte_large_buf_mask, location);
            *target = (void *)&buffer[LARGE_START + LARGE_ELEMENT_SIZE * location];
            *mem_location = NUM_SMALL_BYTE_BUF + location;
            return;
        }
        location = test_dual_location(byte_small_buf_mask, NUM_SMALL_BYTE_BUF - 1);
        if (location >= 0)
        {
            set_dual_bit(&byte_small_buf_mask, location);
            *target = (void *)&buffer[SMALL_ELEMENT_SIZE * location];
            *mem_location = location;
            return;
        }

        return;
    }
}

int test_single_location(int mask, int mask_length)
{
    int location;

    for (location = 0; location < mask_length; location++)
    {
        if ((mask & (1 << location)) == 0)
            return location;
    }
    return -1;
}

void set_single_bit(unsigned char *mask, int location)
{
    *mask = *mask | (1 << location);
}

int test_dual_location(int mask, int mask_length)
{
    int location;

    for (location = 0; location < mask_length; location++)
    {
        if (((mask & (1 << location)) == 0) && ((mask & (1 << (location + 1))) == 0))
            return location;
    }
    return -1;
}

void set_dual_bit(unsigned char *mask, int location)
{
    *mask = *mask | (1 << location);
    *mask = *mask | (1 << (location + 1));
}

void clear_single_bit(unsigned char *mask, int location)
{
    *mask = *mask & ~(1 << location);
}

void clear_dual_bit(unsigned char *mask, int location)
{
    *mask = *mask & ~(1 << location);
    *mask = *mask & ~(1 << (location + 1));
}

void our_free(int type, int mem_location)
{
    if (type == TYPE_SMALL)
    {
        if (mem_location >= 0 && mem_location < NUM_SMALL_BYTE_BUF)
        {
            clear_single_bit(&byte_small_buf_mask, mem_location);
        }
        else if (mem_location >= NUM_SMALL_BYTE_BUF && mem_location < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)
        {
            clear_single_bit(&byte_large_buf_mask, mem_location - NUM_SMALL_BYTE_BUF);
        }
    }
    else /* TYPE_LARGE */
    {
        if (mem_location >= NUM_SMALL_BYTE_BUF && mem_location < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)
        {
            clear_single_bit(&byte_large_buf_mask, mem_location - NUM_SMALL_BYTE_BUF);
        }
        else if (mem_location >= 0 && mem_location < NUM_SMALL_BYTE_BUF)
        {
            clear_dual_bit(&byte_small_buf_mask, mem_location);
        }
    }
}