#include "queue.h"
#include "space.h"

tQueue* createQueue(void){    
    tQueue *queue;
    queue=(tQueue *) malloc (sizeof(tQueue));

    if (queue)
    {
        queue->front=NULL;
        queue->rear=NULL;  
        queue->count=0;
    }

    return queue;
}

int enqueue_node(tQueue *queue, int id, int score, int data_type)
{
    tQueueNode *queue_node;
    void *newptr = NULL;
    int mem_location;

    queue_node = (tQueueNode *) malloc (sizeof(tQueueNode));
    if (!queue_node)
        return 0;

    our_malloc (data_type, (void*)&newptr, &mem_location);

    if (newptr == NULL){
        free(queue_node);
        return 0;
    }

    if (data_type == TYPE_SMALL)
    {
        tQueueSmall *item = (tQueueSmall *) newptr;
        item->id = id;
        item->location = mem_location;
        item->score = score;
        queue_node->content = item;
        queue_node->type = TYPE_SMALL;
    }
    else
    {
        tQueueLarge *item = (tQueueLarge *) newptr;
        item->id = id;
        item->location = mem_location;
        item->score = score;
        queue_node->content = item;
        queue_node->type = TYPE_LARGE;
    }

    queue_node->next = NULL;
    queue_node->prev = NULL;

    if(queue->count==0){
        queue->front=queue_node;
        queue->rear=queue_node; 
    }else{
        queue_node->prev=queue->rear; 
        queue->rear->next=queue_node; 
        queue->rear=queue_node;       
    }
    queue->count++;
    return 1;
}

void dequeue_node(tQueue *queue, tQueueNode *target, int data_type)
{
    if (!target || !queue) return;

    if(target==queue->front&&queue->count==1){
        queue->front=NULL;
        queue->rear=NULL;
    }else if(target==queue->front&&queue->count!=1){
        queue->front=queue->front->next;
        if (queue->front) queue->front->prev=NULL;
    }else if(target==queue->rear){
        queue->rear=queue->rear->prev;
        if (queue->rear) queue->rear->next=NULL;
    }else{
        if (target->prev) target->prev->next=target->next;
        if (target->next) target->next->prev=target->prev;
    }

    queue->count--;

    if (target->type == TYPE_SMALL)
    {
        tQueueSmall *it = (tQueueSmall *) target->content;
        our_free(TYPE_SMALL, it->location);
    }
    else
    {
        tQueueLarge *it = (tQueueLarge *) target->content;
        our_free(TYPE_LARGE, it->location);
    }

    free(target);
}

tQueueNode *find_target_node(tQueue *queue, int id, int data_type)
{
    tQueueNode *target = queue->front;

    while(target!=NULL){
        if (target->type == data_type) {
            if (data_type == TYPE_SMALL) {
                tQueueSmall *it = (tQueueSmall *) target->content;
                if (it->id == id) return target;
            } else {
                tQueueLarge *it = (tQueueLarge *) target->content;
                if (it->id == id) return target;
            }
        }
        target=target->next;
    }

    return NULL;
}


void print_queue (tQueue *queue)
{
    tQueueNode *target = queue->front;

    printf("      type mixed queue: ");
    while (target != NULL)
    {
        if (target->type == TYPE_SMALL)
        {
            tQueueSmall *it = (tQueueSmall *) target->content;
            printf("%d,%d(1,%d) ", it->id, it->score, it->location);
        }
        else
        {
            tQueueLarge *it = (tQueueLarge *) target->content;
            printf("%d,%d(2,%d) ", it->id, it->score, it->location);
        }
        target = target->next;
    }
    printf("\n");
}