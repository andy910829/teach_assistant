#ifndef __QUEUE__
#define __QUEUE__

typedef struct type_small
{
    int id;
    int location;
    int score;
} tQueueSmall;

typedef struct type_large
{
    int id;
    int location;
    int score[8];
} tQueueLarge;

typedef struct node_info
{
    int type;          // TYPE_SMALL (=0) or TYPE_LARGE (=1)
    void *content;
    struct node_info *next;
    struct node_info *prev;
} tQueueNode;

typedef struct
{
    tQueueNode *front;
    tQueueNode *rear;
    int count;
} tQueue;

tQueue *create_queue(void);
int tqueue_enqueue(tQueue *queue, int id, int score, int type);
int tqueue_dequeue(tQueue *queue, int id, int type);
void print_mixed_queue(tQueue *queue);

#endif
