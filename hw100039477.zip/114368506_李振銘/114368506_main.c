#include "main.h"
#include "queue.h"
#include "space.h"

int main(void)
{
    tQueue *queue = create_queue();
    int option;
    int id, score;
    int type;

    if (!queue) {
        printf("Queue create failed!\n");
        return 0;
    }

    while (1)
    {
        printf("Which type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. remove a type 1 item with a specific Id\n");
        printf("4. remove a type 2 item with a specific Id\n");

        if (scanf("%d", &option) != 1) {
            break;
        }

        if (option == 1)
        {
            type = TYPE_SMALL;

            printf("  enter id and score: ");
            if (scanf("%d %d", &id, &score) != 2) break;

            tqueue_enqueue(queue, id, score, type);

            print_buffer_status();
            print_mixed_queue(queue);
        }
        else if (option == 2)
        {
            type = TYPE_LARGE;

            printf("  enter id and score: ");
            if (scanf("%d %d", &id, &score) != 2) break;

            tqueue_enqueue(queue, id, score, type);

            print_buffer_status();
            print_mixed_queue(queue);
        }
        else if (option == 3)
        {
            type = TYPE_SMALL;

            printf("  enter id: ");
            if (scanf("%d", &id) != 1) break;

            tqueue_dequeue(queue, id, type);

            print_buffer_status();
            print_mixed_queue(queue);
        }
        else if (option == 4)
        {
            type = TYPE_LARGE;

            printf("  enter id: ");
            if (scanf("%d", &id) != 1) break;

            tqueue_dequeue(queue, id, type);

            print_buffer_status();
            print_mixed_queue(queue);
        }
        else
        {
            break;
        }

        printf("\n");
    }

    return 0;
}
