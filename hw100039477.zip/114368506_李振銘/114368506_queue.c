#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "space.h"
#include "main.h"


tQueue *create_queue(void)
{
    tQueue *q = (tQueue*)malloc(sizeof(tQueue));
    if (!q) return NULL;

    q->front = q->rear = NULL;
    q->count = 0;
    return q;
}

int tqueue_enqueue(tQueue *queue, int id, int score, int type)
{
    tQueueNode *node;
    void *newptr = NULL;
    int mem_location;

    node = (tQueueNode*)malloc(sizeof(tQueueNode));
    if (!node) return 0;

    our_malloc(type, (void*)&newptr, &mem_location);

    if (newptr == NULL)
    {
        printf("    Enqueue Failed !!! \n\n");
        return 0;
    }

    node->type = type;
    node->content = newptr;
    node->next = node->prev = NULL;

    if (type == TYPE_SMALL)
    {
        tQueueSmall *p = (tQueueSmall*)newptr;
        p->id = id;
        p->location = mem_location;
        p->score = score;
    }
    else
    {
        tQueueLarge *p = (tQueueLarge*)newptr;
        p->id = id;
        p->location = mem_location;
        p->score[0] = score;
        for (int i = 1; i < 8; i++) p->score[i] = 0;
    }

    if (queue->rear == NULL)
    {
        queue->front = queue->rear = node;
    }
    else
    {
        queue->rear->next = node;
        node->prev = queue->rear;
        queue->rear = node;
    }

    queue->count++;
    return 1;
}

static tQueueNode* find_node(tQueue *queue, int id, int type)
{
    tQueueNode *cur = queue->front;

    while (cur)
    {
        if (cur->type == type)
        {
            if (type == TYPE_SMALL)
            {
                tQueueSmall *p = (tQueueSmall*)cur->content;
                if (p->id == id) return cur;
            }
            else
            {
                tQueueLarge *p = (tQueueLarge*)cur->content;
                if (p->id == id) return cur;
            }
        }
        cur = cur->next;
    }
    return NULL;
}

int tqueue_dequeue(tQueue *queue, int id, int type)
{
    tQueueNode *node = find_node(queue, id, type);
    if (!node)
    {
        printf("    cannot find the id\n");
        return 0;
    }

    if (type == TYPE_SMALL)
    {
        tQueueSmall *p = (tQueueSmall*)node->content;
        our_free(type, p->location);
    }
    else
    {
        tQueueLarge *p = (tQueueLarge*)node->content;
        our_free(type, p->location);
    }

    if (node->prev) {
        node->prev->next = node->next;
    }
    else {
        queue->front = node->next;
    }

    if (node->next) {
        node->next->prev = node->prev;
    }
    else {
        queue->rear = node->prev;
    }

    free(node);
    queue->count--;
    return 1;
}

void print_mixed_queue(tQueue *queue)
{
    tQueueNode *cur = queue->front;

    printf("      type mixed queue: ");

    while (cur)
    {
        int show_type = (cur->type == TYPE_SMALL ? 1 : 2);

        if (cur->type == TYPE_SMALL)
        {
            tQueueSmall *p = (tQueueSmall*)cur->content;
            int loc = p->location;
            printf("%d,%d(%d,%d) ", p->id, p->score, show_type, loc);
        }
        else
        {
            tQueueLarge *p = (tQueueLarge*)cur->content;
            int loc = p->location + NUM_SMALL_BYTE_BUF;
            printf("%d,%d(%d,%d) ", p->id, p->score[0], show_type, loc);
        }

        cur = cur->next;
    }

    printf("\n");
}

