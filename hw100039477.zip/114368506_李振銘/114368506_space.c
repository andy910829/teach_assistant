#include <stdio.h>
#include "space.h"

unsigned char buffer[
    NUM_SMALL_BYTE_BUF * SMALL_ELEMENT_SIZE +
    NUM_LARGE_BYTE_BUF * LARGE_ELEMENT_SIZE
];

unsigned char byte_small_buf_mask = 0;
unsigned char byte_large_buf_mask = 0;

static int is_bit_used(unsigned char mask, int index)
{
    return (mask & (1 << index)) ? 1 : 0;
}
static void set_bit(unsigned char *mask, int index)
{
    *mask |= (1 << index);
}
static void clear_bit(unsigned char *mask, int index)
{
    *mask &= ~(1 << index);
}

static int find_free_slot(unsigned char mask)
{
    for (int i = 0; i < 8; i++)
        if (!is_bit_used(mask, i))
            return i;
    return -1;
}

void print_buffer_status(void)
{
    printf("      byte_small_buf_mask: ");
    for (int i = 7; i >= 0; i--)
        printf("%d ", is_bit_used(byte_small_buf_mask, i));
    printf("\n");

    printf("      byte_large_buf_mask: ");
    for (int i = 7; i >= 0; i--)
        printf("%d ", is_bit_used(byte_large_buf_mask, i));
    printf("\n");
}

void our_malloc(int type, void **target, int *mem_location)
{
    int slot = -1;

    *target = NULL;
    *mem_location = -1;

    if (type == TYPE_SMALL)    // 0
    {
        slot = find_free_slot(byte_small_buf_mask);
        if (slot < 0) return;

        set_bit(&byte_small_buf_mask, slot);

        *target = &buffer[slot * SMALL_ELEMENT_SIZE];
        *mem_location = slot;
    }
    else                       // TYPE_LARGE = 1
    {
        slot = find_free_slot(byte_large_buf_mask);
        if (slot < 0) return;

        set_bit(&byte_large_buf_mask, slot);

        *target = &buffer[LARGE_START + slot * LARGE_ELEMENT_SIZE];
        *mem_location = slot;
    }
}

void our_free(int type, int mem_location)
{
    if (mem_location < 0 || mem_location >= 8)
        return;

    if (type == TYPE_SMALL)
        clear_bit(&byte_small_buf_mask, mem_location);
    else
        clear_bit(&byte_large_buf_mask, mem_location);
}
