#ifndef __QUEUE__
#define __QUEUE__

typedef struct type_small {
    int id;
    int location;
    int score;
    int data_type; /* number of units occupied */
} tQueueSmall;

typedef struct type_large {
    int id;
    int location;
    int score[8];
    int data_type; /* number of units occupied */
} tQueueLarge;

typedef struct node_info{
    int type;
    void *content;
    struct node_info *next;
    struct node_info *prev;
}tQueueNode;

typedef struct{
    tQueueNode *front;
    tQueueNode *rear;
    int count;
}tQueue;

// ----------------------------------------------------------------------------
tQueue* createQueue(void);

int enqueue_type_small(tQueue *queue, int id, int score, int data_type);
int dequeue_type_small(tQueue *queue, tQueueSmall *target, int data_type);

tQueueSmall *find_target_small_node(tQueue *queue, int id);

/* type 2 (large) APIs */
int enqueue_type_large(tQueue *queue, int id, int score);
int dequeue_type_large(tQueue *queue, tQueueLarge *target);
tQueueLarge *find_target_large_node(tQueue *queue, int id);

void print_queue(tQueue *queue);

#endif
