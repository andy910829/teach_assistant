#include "main.h"
#include "queue.h"
#include "space.h"

int main (void)
{
    tQueue *queue;
    int operation;
    tQueueSmall *target_type_small;
    int id, score = 0, ret;
    int units;

    queue = createQueue();

    while (1)
    {
        printf("Remaining memory space %d\n", get_remaining_space());
        printf("Which type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. remove a type 1 item with a specific Id\n");
        printf("4. remove a type 2 item with a specific Id\n");

        scanf("%d", &operation);

        if (operation == 1)
        {
            printf("  enter id and score: ");
            scanf("%d", &id);
            scanf("%d", &score);

            ret = enqueue_type_small(queue, id, score, 1);
            if (ret == 0)
            {
                printf("    Enqueue False!!! \n");
            }
            print_buffer_status();
        }
        else if (operation == 2)
        {
            printf("  enter id and score: ");
            scanf("%d", &id);
            scanf("%d", &score);

            ret = enqueue_type_large(queue, id, score);
            if (ret == 0)
            {
                printf("    Enqueue False!!! \n");
            }
            print_buffer_status();
        }
        else if (operation == 3)
        {
            printf("  enter an ID to remove \n");
            scanf("%d", &id);

            target_type_small = find_target_small_node(queue, id);
            if (target_type_small == NULL)
            {
                printf("    cannot find the target node \n");
            }
            else
            {
                printf("target type: 1, location: %d, id: %d\n", target_type_small->location, target_type_small->id);
                /* data_type 變成「佔用的 units 數量」 */
                dequeue_type_small(queue, target_type_small, target_type_small->data_type);
            }
            print_buffer_status();
        }
        else if (operation == 4)
        {
            printf("  enter an ID to remove \n");
            scanf("%d", &id);

            {
                tQueueLarge *target_large = find_target_large_node(queue, id);
                if (target_large == NULL)
                {
                    printf("    cannot find the target node \n");
                }
                else
                {
                    printf("target type: 2, location: %d, id: %d\n", target_large->location, target_large->id);
                    dequeue_type_large(queue, target_large);
                }
            }
            print_buffer_status();
        }
        else
        {
            printf("    no such operation \n");
        }

        print_queue(queue);
    }

    return 0;
}
