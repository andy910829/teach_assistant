#include "space.h"
#include <string.h>
/*
 * Two-buffer allocator
 * - small_buffer: NUM_SMALL_BTYE_BUF elements of SMALL_ELEMENT_SIZE bytes
 * - large_buffer: NUM_LARGE_BYTE_BUF elements of LARGE_ELEMENT_SIZE bytes
 * Logical allocation units are SMALL_ELEMENT_SIZE bytes; TOTAL_UNITS counts those.
 * Allocations will be given only when the requested contiguous units fit entirely
 * within the small region or entirely within the large region (no crossing the boundary).
 */

static unsigned char small_buffer[NUM_SMALL_BTYE_BUF * SMALL_ELEMENT_SIZE];
static unsigned char large_buffer[NUM_LARGE_BYTE_BUF * LARGE_ELEMENT_SIZE];

static unsigned char *occupied_mask = NULL;
static unsigned char *start_mask    = NULL;

static int remaining_space = TOTAL_UNITS;

static int get_bit(unsigned char *mask, int idx)
{
    int byte_idx = idx / 8;
    int bit_idx  = idx % 8;
    unsigned char bit = (unsigned char)(1u << bit_idx);
    return (mask[byte_idx] & bit) ? 1 : 0;
}

static void set_bit(unsigned char *mask, int idx)
{
    int byte_idx = idx / 8;
    int bit_idx  = idx % 8;
    unsigned char bit = (unsigned char)(1u << bit_idx);
    mask[byte_idx] |= bit;
}

static void clear_bit(unsigned char *mask, int idx)
{
    int byte_idx = idx / 8;
    int bit_idx  = idx % 8;
    unsigned char bit = (unsigned char)(1u << bit_idx);
    mask[byte_idx] &= (unsigned char)(~bit);
}

void space_init(void)
{
    if (occupied_mask == NULL) {
        occupied_mask = (unsigned char *)malloc(MASK_BYTES);
        if (occupied_mask == NULL) {
            printf("space_init: failed to allocate occupied_mask\n");
            return;
        }
        memset(occupied_mask, 0, MASK_BYTES);
    }

    if (start_mask == NULL) {
        start_mask = (unsigned char *)malloc(MASK_BYTES);
        if (start_mask == NULL) {
            printf("space_init: failed to allocate start_mask\n");
            return;
        }
        memset(start_mask, 0, MASK_BYTES);
    }

    remaining_space = TOTAL_UNITS;
}

void space_release(void)
{
    if (occupied_mask) {
        free(occupied_mask);
        occupied_mask = NULL;
    }
    if (start_mask) {
        free(start_mask);
        start_mask = NULL;
    }
}

int get_remaining_space(void)
{
    return remaining_space;
}

void print_buffer_status(void)
{
    int i, s, u;

    /* print small buffer per-unit bits (NUM_SMALL_BTYE_BUF units) */
    printf("      byte_small_buf_mask: ");
    for (i = NUM_SMALL_BTYE_BUF - 1; i >= 0; i--) {
        int bit = get_bit(occupied_mask, i);
        printf("%d ", bit);
    }
    printf("\n");

    /* print large buffer per-slot bits (one bit per large slot)
     * large slot s maps to units starting at NUM_SMALL_BTYE_BUF + s*UNITS_PER_LARGE
     */
    printf("      byte_large_buf_mask: ");
    for (s = NUM_LARGE_BYTE_BUF - 1; s >= 0; s--) {
        int any = 0;
        int base = NUM_SMALL_BTYE_BUF + s * UNITS_PER_LARGE;
        for (u = 0; u < UNITS_PER_LARGE; u++) {
            if (get_bit(occupied_mask, base + u)) {
                any = 1;
                break;
            }
        }
        printf("%d ", any);
    }
    printf("\n");
}

/* Map unit index to a pointer inside small_buffer or large_buffer.
 * Assumes index and count are such that the entire allocation sits within one region.
 */
static void *unit_index_to_ptr(int unit_index)
{
    if (unit_index < 0 || unit_index >= TOTAL_UNITS)
        return NULL;

    if (unit_index < NUM_SMALL_BTYE_BUF) {
        return &small_buffer[unit_index * SMALL_ELEMENT_SIZE];
    }
    else {
        int offset_units = unit_index - NUM_SMALL_BTYE_BUF; /* units inside large area */
        int units_per_large = (LARGE_ELEMENT_SIZE / SMALL_ELEMENT_SIZE);
        int large_slot = offset_units / units_per_large;
        int intra_offset_units = offset_units % units_per_large;
        return &large_buffer[large_slot * LARGE_ELEMENT_SIZE + intra_offset_units * SMALL_ELEMENT_SIZE];
    }
}

void our_malloc(int size_units, void **target, int *mem_location)
{
    int i, j, found;

    if (!occupied_mask || !start_mask) {
        space_init();
    }

    *target = NULL;
    if (size_units <= 0 || size_units > TOTAL_UNITS) {
        return;
    }

    if (remaining_space < size_units) {
        return;
    }

    /* Find a contiguous run of size_units that does not cross the small/large boundary */
    found = 0;
    for (i = 0; i <= TOTAL_UNITS - size_units; i++) {
        /* ensure allocation doesn't cross the region boundary */
        if (i < NUM_SMALL_BTYE_BUF && (i + size_units) > NUM_SMALL_BTYE_BUF) {
            /* would cross from small to large: skip */
            continue;
        }

        int ok = 1;
        for (j = 0; j < size_units; j++) {
            if (get_bit(occupied_mask, i + j)) {
                ok = 0;
                break;
            }
        }
        if (ok) {
            found = 1;
            break;
        }
    }

    if (!found) {
        return;
    }

    /* Mark bits as occupied and record start */
    for (j = 0; j < size_units; j++) {
        set_bit(occupied_mask, i + j);
    }
    set_bit(start_mask, i);

    *mem_location = i;
    *target = unit_index_to_ptr(i);

    remaining_space -= size_units;
}

/* Allocate size_units but only from the large-buffer region, aligned to large slots.
 * Returns mem_location as the unit index (>= NUM_SMALL_BTYE_BUF) on success.
 */
void our_malloc_large(int size_units, void **target, int *mem_location)
{
    int i, j, found = 0;

    if (!occupied_mask || !start_mask) {
        space_init();
    }

    *target = NULL;
    if (size_units <= 0 || size_units > TOTAL_UNITS) {
        return;
    }

    /* Search only within the large-region unit indices for a contiguous run */
    for (i = NUM_SMALL_BTYE_BUF; i <= TOTAL_UNITS - size_units; i++) {
        int ok = 1;
        for (j = 0; j < size_units; j++) {
            if (get_bit(occupied_mask, i + j)) {
                ok = 0; break;
            }
        }
        if (ok) { found = 1; break; }
    }

    if (!found) return;

    for (j = 0; j < size_units; j++) {
        set_bit(occupied_mask, i + j);
    }
    set_bit(start_mask, i);

    *mem_location = i;
    *target = unit_index_to_ptr(i);

    remaining_space -= size_units;
}

void our_free(int size_units, int mem_location)
{
    int j;

    if (!occupied_mask || !start_mask)
        return;

    if (size_units <= 0)
        return;

    if (mem_location < 0 || mem_location >= TOTAL_UNITS)
        return;

    for (j = 0; j < size_units; j++) {
        if (mem_location + j < TOTAL_UNITS) {
            clear_bit(occupied_mask, mem_location + j);
        }
    }
    clear_bit(start_mask, mem_location);

    remaining_space += size_units;
    if (remaining_space > TOTAL_UNITS)
        remaining_space = TOTAL_UNITS;
}
