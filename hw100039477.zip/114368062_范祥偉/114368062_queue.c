#include "queue.h"
#include "space.h"

int tqueue_enqueue(tQueue *queue, int id, int score, int type)
{
    tQueueNode *queue_node;
    void *newptr = NULL;
    int mem_location;

    queue_node = (tQueueNode *)malloc(sizeof(tQueueNode));

    if(newptr == NULL){
        printf("    Enqueue False!!! \n\n");
        return 0;
    }
}
// ----------------------------------------------------------------------------
tQueue* createQueue(void)
{
    tQueue *queue;
    queue = (tQueue *) malloc(sizeof(tQueue));

    if (queue)
    {
        queue->front = NULL;
        queue->rear  = NULL;
        queue->count = 0;
    }

    space_init();

    return queue;
}

int enqueue_type_small(tQueue *queue, int id, int score, int data_type)
{
    tQueueSmall *payload = NULL;
    int mem_location;

    if (queue == NULL)
        return 0;

    our_malloc(data_type, (void**)&payload, &mem_location);

    if (payload == NULL)
    {
        printf("    Enqueue False!!! \n");
        return 0;
    }

    /* initialize payload inside allocated memory */
    payload->id = id;
    payload->score = score;
    payload->location = mem_location;
    payload->data_type = data_type;

    /* create node */
    tQueueNode *node = (tQueueNode *)malloc(sizeof(tQueueNode));
    if (!node) {
        our_free(data_type, mem_location);
        printf("    Enqueue False!!! \n");
        return 0;
    }

    node->type = TYPE_SMALL;
    node->content = (void *)payload;
    node->next = NULL;
    node->prev = NULL;

    if (queue->count == 0) {
        queue->front = node;
        queue->rear = node;
    } else {
        node->prev = queue->rear;
        queue->rear->next = node;
        queue->rear = node;
    }

    queue->count++;
    return 1;
}

/* ------------------ large type ------------------ */
int enqueue_type_large(tQueue *queue, int id, int score)
{
    tQueueLarge *payload = NULL;
    int mem_location;

    if (queue == NULL)
        return 0;

    /* allocate UNITS_PER_LARGE units for a large item */
    /* allocate UNITS_PER_LARGE units specifically from the large region (aligned per large-slot) */
    our_malloc_large(UNITS_PER_LARGE, (void**)&payload, &mem_location);
    if (payload == NULL)
    {
        printf("    Enqueue False!!! \n");
        return 0;
    }

    /* initialize payload */
    payload->id = id;
    payload->location = mem_location;
    payload->data_type = UNITS_PER_LARGE;
    /* store single score in first element for compatibility */
    payload->score[0] = score;

    tQueueNode *node = (tQueueNode *)malloc(sizeof(tQueueNode));
    if (!node) {
        our_free(UNITS_PER_LARGE, mem_location);
        printf("    Enqueue False!!! \n");
        return 0;
    }

    node->type = TYPE_LARGE;
    node->content = (void *)payload;
    node->next = NULL;
    node->prev = NULL;

    if (queue->count == 0) {
        queue->front = node;
        queue->rear = node;
    } else {
        node->prev = queue->rear;
        queue->rear->next = node;
        queue->rear = node;
    }

    queue->count++;
    return 1;
}

int dequeue_type_large(tQueue *queue, tQueueLarge *target)
{
    tQueueNode *cur;

    if (queue == NULL || target == NULL || queue->count == 0)
        return 0;

    cur = queue->front;
    while (cur != NULL) {
        if (cur->content == (void *)target)
            break;
        cur = cur->next;
    }
    if (cur == NULL)
        return 0;

    if (cur->prev)
        cur->prev->next = cur->next;
    else
        queue->front = cur->next;

    if (cur->next)
        cur->next->prev = cur->prev;
    else
        queue->rear = cur->prev;

    queue->count--;

    our_free(target->data_type, target->location);
    free(cur);
    return 1;
}

tQueueLarge *find_target_large_node(tQueue *queue, int id)
{
    tQueueNode *cur;

    if (queue == NULL)
        return NULL;

    cur = queue->front;
    while (cur != NULL) {
        if (cur->type == TYPE_LARGE) {
            tQueueLarge *p = (tQueueLarge *)cur->content;
            if (p && p->id == id)
                return p;
        }
        cur = cur->next;
    }
    return NULL;
}

int dequeue_type_small(tQueue *queue, tQueueSmall *target, int data_type)
{
    tQueueNode *cur;

    if (queue == NULL || target == NULL || queue->count == 0)
        return 0;

    /* find node whose content pointer equals target */
    cur = queue->front;
    while (cur != NULL) {
        if (cur->content == (void *)target)
            break;
        cur = cur->next;
    }

    if (cur == NULL)
        return 0;

    /* unlink */
    if (cur->prev)
        cur->prev->next = cur->next;
    else
        queue->front = cur->next;

    if (cur->next)
        cur->next->prev = cur->prev;
    else
        queue->rear = cur->prev;

    queue->count--;

    our_free(data_type, target->location);
    free(cur);

    return 1;
}

tQueueSmall *find_target_small_node(tQueue *queue, int id)
{
    tQueueNode *cur;

    if (queue == NULL)
        return NULL;

    cur = queue->front;

    while (cur != NULL)
    {
        if (cur->type == TYPE_SMALL) {
            tQueueSmall *p = (tQueueSmall *)cur->content;
            if (p && p->id == id)
                return p;
        }
        cur = cur->next;
    }

    return NULL;
}

void print_queue (tQueue *queue)
{
    tQueueNode *cur = queue->front;
    printf("      type mixed queue: ");
    while (cur != NULL) {
        if (cur->type == TYPE_SMALL) {
            tQueueSmall *p = (tQueueSmall *)cur->content;
            if (p)
                printf("%d,%d(%d,%d) ", p->id, p->score, p->data_type, p->location);
        }
        else if (cur->type == TYPE_LARGE) {
            tQueueLarge *p = (tQueueLarge *)cur->content;
            if (p) {
                int display_loc = p->location;
                if (p->location >= NUM_SMALL_BTYE_BUF) {
                    int slot = (p->location - NUM_SMALL_BTYE_BUF) / UNITS_PER_LARGE;
                    display_loc = NUM_SMALL_BTYE_BUF + slot; /* 8,9,10... as in demo */
                }
                printf("%d,%d(%d,%d) ", p->id, p->score[0], p->data_type, display_loc);
            }
        }
        cur = cur->next;
    }
    printf("\n\n");
}
