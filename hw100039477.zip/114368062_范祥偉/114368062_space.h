#ifndef __SPACE__
#define __SPACE__

#include "main.h"

#define NUM_SMALL_BTYE_BUF  8
#define NUM_LARGE_BYTE_BUF  8

#define SMALL_ELEMENT_SIZE  32
#define LARGE_ELEMENT_SIZE  64
#define LARGE_START        (SMALL_ELEMENT_SIZE*NUM_SMALL_BTYE_BUF)

/* Compute total units: each large element = LARGE_ELEMENT_SIZE / SMALL_ELEMENT_SIZE units */
#define UNITS_PER_LARGE (LARGE_ELEMENT_SIZE / SMALL_ELEMENT_SIZE)
#define TOTAL_UNITS (NUM_SMALL_BTYE_BUF + NUM_LARGE_BYTE_BUF * UNITS_PER_LARGE)

/* mask bytes to represent TOTAL_UNITS bits */
#define MASK_BYTES ((TOTAL_UNITS + 7) / 8)

//----------------------------------------------------------------------------
void print_buffer_status(void);


void our_malloc(int size_units, void **target, int *mem_location);
void our_malloc_large(int size_units, void **target, int *mem_location);
void our_free(int size_units, int mem_location);

int get_remaining_space(void);

void space_init(void);
void space_release(void);

#endif
