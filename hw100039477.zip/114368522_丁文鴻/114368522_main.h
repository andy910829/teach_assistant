#ifndef __MAIN__
#define __MAIN__

#include <stdio.h>
#include <stdlib.h>

// 作業中用到的操作選項
#define OPERATION_ADD_TYPE1         1
#define OPERATION_ADD_TYPE2         2
#define OPERATION_REMOVE_TYPE1      3
#define OPERATION_REMOVE_TYPE2      4
#define OPERATION_EXIT              5

// 項目類型和所需單元數 (Size)
#define ITEM_TYPE_1                 1   // Type 1 項目標識
#define ITEM_TYPE_2                 2   // Type 2 項目標識

#define SIZE_TYPE_1                 1   // Type 1 佔用 1 個單元
#define SIZE_TYPE_2                 2   // Type 2 佔用 2 個單元

#endif