#ifndef __QUEUE__
#define __QUEUE__

typedef struct queue_node {
    int id;
    int score;
    int location;
    int size;          
    int item_type;     
    struct queue_node *next;
    struct queue_node *prev;
}tQueueNode;

typedef struct {
    tQueueNode *front;
    tQueueNode *rear;
    int count;
}tQueue;


tQueue* createQueue(void);


int enqueue_node(tQueue *queue, int id, int score, int item_type, int size); 
void dequeue_node(tQueue *queue, tQueueNode *target); 


tQueueNode *find_target_node_by_id(tQueue *queue, int id, int target_item_type); 

void print_queue(tQueue *queue);

#endif