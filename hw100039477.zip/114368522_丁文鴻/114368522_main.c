#include "main.h"
#include "queue.h"
#include "space.h"
#include <stdio.h>
#include <stdlib.h> 


int main (void)
{
    tQueue *queue;
    int operation;
    tQueueNode *target_node;
    int id, score;
    int item_type_to_add;
    int size_to_add;
    int item_type_to_remove;


    init_memory_manager(); 
    
    queue = createQueue();

    while (1)
    {

        print_buffer_status();
        print_queue(queue);


        printf("\nWhich type you are going to operate? \n");
        printf("%d. Add a type 1 item\n", OPERATION_ADD_TYPE1);
        printf("%d. Add a type 2 item\n", OPERATION_ADD_TYPE2);
        printf("%d. remove a type 1 item with a specific Id\n", OPERATION_REMOVE_TYPE1);
        printf("%d. remove a type 2 item with a specific Id\n", OPERATION_REMOVE_TYPE2);
        printf("%d. Exit\n", OPERATION_EXIT);
        

        if (scanf("%d", &operation) != 1) {
            while (getchar() != '\n');
            printf("Invalid input. Please enter a number 1-5.\n");
            continue;
        }

        if (operation == OPERATION_EXIT)
        {
            break;
        }


        if (operation == OPERATION_ADD_TYPE1 || operation == OPERATION_ADD_TYPE2)
        {

            if (operation == OPERATION_ADD_TYPE1) {
                item_type_to_add = ITEM_TYPE_1;
                size_to_add = SIZE_TYPE_1;
            } else {
                item_type_to_add = ITEM_TYPE_2;
                size_to_add = SIZE_TYPE_2;
            }
            
            printf("  enter id and score: ");
            if (scanf("%d %d", &id, &score) != 2) {
                 while (getchar() != '\n');
                 printf("Invalid input.\n");
                 continue;
            }


            enqueue_node(queue, id, score, item_type_to_add, size_to_add); 
        }


        else if (operation == OPERATION_REMOVE_TYPE1 || operation == OPERATION_REMOVE_TYPE2)
        {

            if (operation == OPERATION_REMOVE_TYPE1) {
                item_type_to_remove = ITEM_TYPE_1;
            } else {
                item_type_to_remove = ITEM_TYPE_2;
            }
            
            printf ("  enter an ID to remove \n");
            if (scanf("%d", &id) != 1) {
                while (getchar() != '\n');
                printf("Invalid input.\n");
                continue;
            }
            

            target_node = find_target_node_by_id(queue, id, item_type_to_remove);
            
            if (target_node == NULL)
            {

                printf ("cannot find the target node\n");
            }
            else
            {
                dequeue_node(queue, target_node); 
                printf ("Item with ID %d removed.\n", id);
            }
        }
        else
        {
            printf("Invalid operation.\n");
        }
    }
    

    if (byte_buf_mask) free(byte_buf_mask);
    if (queue) free(queue);

    return 0;
}