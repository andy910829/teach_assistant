#include "queue.h"
#include "space.h"
#include "main.h" 
#include <stdio.h>
#include <stdlib.h>


tQueue* createQueue(void){    
    tQueue *queue;

    queue=(tQueue *) malloc (sizeof(tQueue)); 

    if (queue)
    {
        queue->front=NULL;
        queue->rear=NULL;  
        queue->count=0;
    }

    return queue;
}


int enqueue_node(tQueue *queue, int id, int score, int item_type, int size)
{
    tQueueNode *newptr = NULL;
    int mem_location;


    our_malloc (size, (void **)&newptr, &mem_location);
    
    if (newptr == NULL)
    {
        printf("    Enqueue Failed !!!\n");
        printf("Cannot enter to the queue\n");
        return 0;
    }
    

    newptr->id = id;
    newptr->score = score;
    newptr->item_type = item_type;  
    newptr->size = size;            
    newptr->location = mem_location; 
    newptr->next = NULL;
    newptr->prev = NULL; 


    if (queue->rear == NULL)
    {
        queue->front = newptr;
        queue->rear = newptr;
    }
    else
    {
        newptr->prev = queue->rear; 
        queue->rear->next = newptr;
        queue->rear = newptr;
    }
    
    queue->count++;
        
    return 1;
}


void dequeue_node(tQueue *queue, tQueueNode *target)
{
    if (target == NULL) return;
    

    printf("target type: %d, location: %d, id: %d\n", 
           target->item_type, target->location, target->id);
    
    if (target->next != NULL) {
        printf("target next type: %d, location: %d, id: %d\n", 
               target->next->item_type, target->next->location, target->next->id);
    }
    

    if (target->prev != NULL) {
        target->prev->next = target->next;
    } else {
        queue->front = target->next;
    }

    if (target->next != NULL) {
        target->next->prev = target->prev;
    } else {
        queue->rear = target->prev;
    }

    queue->count--;
    

    our_free(target->size, target->location);
      
}


tQueueNode *find_target_node_by_id(tQueue *queue, int id, int target_item_type)
{
    tQueueNode *target = queue->front;
    
    while (target != NULL)
    {

        if (target->id == id && target->item_type == target_item_type)
        {
            return target; 
        }
        target = target->next;
    }
    
    return NULL;
}


void print_queue(tQueue *queue)
{
    tQueueNode *current = queue->front;
    printf("      type mixed queue: ");
    
    while (current != NULL)
    {
        
        printf("%d,%d(%d,%d) ", current->id, current->score, current->item_type, current->location);
        current = current->next;
    }
    printf("\n");
}