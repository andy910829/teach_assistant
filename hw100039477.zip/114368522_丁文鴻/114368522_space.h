#ifndef __SPACE__
#define __SPACE__

#include "main.h"

// 設定記憶體配置
#define UNIT_ELEMENT_SIZE      32     // 每個單元 32 bytes
#define NUM_UNITS              23     // 管理 23 個單元 (0-22)
#define NUM_MASK_BYTES         3      // 位元圖使用 3 個 bytes (24 bits, 0-23)
#define MAX_MEM_SIZE           (UNIT_ELEMENT_SIZE * NUM_UNITS) 



extern unsigned char buffer[MAX_MEM_SIZE];
extern unsigned char *byte_buf_mask; 


void init_memory_manager(void); 
void print_buffer_status(void);


void our_malloc(int size, void **target, int *mem_location);
void our_free(int size, int mem_location);  


int test_n_location(int n); 
void set_n_bit(int location, int n); 
void clear_n_bit(int location, int n); 

#endif