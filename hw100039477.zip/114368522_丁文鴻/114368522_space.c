#include "space.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


unsigned char buffer[MAX_MEM_SIZE];
unsigned char *byte_buf_mask = NULL; 
static int remaining_units = NUM_UNITS; 



void init_memory_manager(void)
{
    
    byte_buf_mask = (unsigned char *)calloc(NUM_MASK_BYTES, sizeof(unsigned char));
    if (byte_buf_mask == NULL) {
        printf("Error: Failed to allocate byte_buf_mask.\n");
        exit(1);
    }
    remaining_units = NUM_UNITS;
}



#define GET_BYTE_INDEX(loc) ( NUM_MASK_BYTES - 1 - ((loc) / 8) ) 


#define GET_BIT_MASK(loc) ( 0x01 << ((loc) % 8) ) 



static int is_bit_set(int location) {
    if (location < 0 || location >= NUM_UNITS) return 0;
    int byte_idx = GET_BYTE_INDEX(location);
    unsigned char mask = GET_BIT_MASK(location);
    return (byte_buf_mask[byte_idx] & mask) != 0;
}

static void set_bit(int location) {
    if (location < 0 || location >= NUM_UNITS) return;
    int byte_idx = GET_BYTE_INDEX(location);
    unsigned char mask = GET_BIT_MASK(location);
    byte_buf_mask[byte_idx] |= mask;
}

static void clear_bit(int location) {
    if (location < 0 || location >= NUM_UNITS) return;
    int byte_idx = GET_BYTE_INDEX(location);
    unsigned char mask = GET_BIT_MASK(location);
    byte_buf_mask[byte_idx] &= ~mask;
}



int test_n_location(int n)
{
    int location;
    
    if (n <= 0 || n > NUM_UNITS) return -1;
    
    for (location = 0; location <= NUM_UNITS - n; location++)
    {
        int i;
        int found = 1;
        
        for (i = 0; i < n; i++)
        {
            if (is_bit_set(location + i))
            {
                found = 0; 
                location += i;
                break;
            }
        }
        
        if (found)
        {
            return location;
        }
    }
    
    return -1; 
}


void set_n_bit(int location, int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        set_bit(location + i);
    }
    remaining_units -= n;
}


void clear_n_bit(int location, int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        clear_bit(location + i);
    }
    remaining_units += n;
}



void our_malloc(int size, void **target, int *mem_location)
{
    *mem_location = -1; 
    *target = NULL;    

    if (remaining_units < size)
    {
        return; 
    }
    
    int location = test_n_location(size);

    if (location != -1)
    {
 
        set_n_bit(location, size);
        

        *target = &buffer[location * UNIT_ELEMENT_SIZE];
        

        *mem_location = location;
    }
}



void our_free(int size, int mem_location)
{
    if (mem_location >= 0 && mem_location < NUM_UNITS)
    {
        clear_n_bit(mem_location, size);
    }
}



static void print_byte_mask_in_binary(unsigned char byte) {
    int i;

    for (i = 7; i >= 0; i--) {
        printf("%d ", (byte >> i) & 0x01);
    }
}

void print_buffer_status(void)
{

    printf("      byte_small_buf_mask: ");
    print_byte_mask_in_binary(byte_buf_mask[2]);
    printf("\n");


    printf("      byte_large_buf_mask: ");
    print_byte_mask_in_binary(byte_buf_mask[1]);
    printf("\n");
}