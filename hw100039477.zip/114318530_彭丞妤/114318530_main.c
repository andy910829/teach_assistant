#include "main.h"
#include "queue.h"
#include "space.h"

int main (void)
{
    tQueue *queue;
    int operation;
    int size = 0;
    tQueueNode *target_node;
    int id, score, ret;
    queue = createQueue();

    while (1)
    {

        printf("Which type you are going to operate? \n");
        printf("1. Add a type 1 item\n");
        printf("2. Add a type 2 item\n");
        printf("3. remove a type 1 item with a specific Id\n");
        printf("4. remove a type 2 item with a specific Id\n");
        
        scanf("%d", &operation);
        
        if (operation == 1 || operation == 2)
        {
            printf("  enter id and score: ");
            scanf("%d", &id);
            scanf("%d", &score);

            ret = tqueue_enqueue(queue, id, score, operation);
          
            if (ret == 0)
            {
                printf("    Cannot enter to the queue\n");
            }
            print_buffer_status();
        }
        else if (operation == 3 ||operation == 4)
        {
            printf ("  Enter an ID to remove ");
            scanf("%d", &id);
            int type = operation-2;
            target_node = find_target_node(&queue, id, type);
            if (target_node == NULL)
            {
                printf ("    Cannot find the target node \n");
            }
            else
            {
                print_target_info(&target_node, type);
                dequeue_node(&queue, &target_node, type);
            }
            print_buffer_status();

        }
        print_queue(&queue);
    }

}
