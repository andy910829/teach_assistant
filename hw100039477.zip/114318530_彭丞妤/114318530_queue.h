#ifndef __QUEUE__
#define __QUEUE__

typedef struct type_small {
    int id;
    int location;
    int score;
}tQueueSmall; 

typedef struct type_large {
    int id;
    int location;
    int score[8];
}tQueueLarge; 

typedef struct node_info {
    int type;
    void *content;
    struct node_info *next;
    struct node_info *prev;
}tQueueNode;

typedef struct  {
    tQueueNode *front;
    tQueueNode *rear;
    int count;
}tQueue;


tQueue* createQueue(void);

int tqueue_enqueue(tQueue *queue, int id, int score, int type);
void dequeue_node(tQueue **queue, tQueueNode **target, int type);
void print_target_info(tQueueNode **target, int type);
tQueueNode *find_target_node(tQueue **queue, int id, int type);

void print_queue(tQueue **queue);

#endif