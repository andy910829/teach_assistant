#include "space.h"

unsigned char buffer[SMALL_ELEMENT_SIZE*NUM_SMALL_BYTE_BUF + LARGE_ELEMENT_SIZE*NUM_LARGE_BYTE_BUF];
unsigned char byte_small_buf_mask = 0;
unsigned char byte_large_buf_mask = 0;

// 配置buf空間，計算共需多少bytes，並初始化為0
// void our_buf_mask(void){  
//     // int byte_num = (NUM_BYTE_BUF+7) / 8;
//     byte_buf_mask = (unsigned char *)malloc(sizeof(unsigned char) * (NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF));
//     for(int i = 0; i < byte_num; i++){ // mask初始化
//         byte_buf_mask[i] = 0;
//     }
// }

void print_buffer_status (void)
{  
    printf ("      byte_small_buf_mask: ");
    for(int i = NUM_SMALL_BYTE_BUF-1; i >= 0; i--){
        printf ("%d ", byte_small_buf_mask  >> i & 1);
    }
    printf ("\n      byte_large_buf_mask: ");
    for(int i = NUM_LARGE_BYTE_BUF-1; i >= 0; i--){
        printf ("%d ", byte_large_buf_mask  >> i & 1);
    }
    printf ("\n");
}

//挖空間
void our_malloc(int type, void **target, int *location )
{
    *target = NULL;
    
    *location = test_location(type);
    if(*location == -1){
        return;
    }
    set_bit(*location, type);
    int size = (type == 1)? SMALL_ELEMENT_SIZE:LARGE_ELEMENT_SIZE;
    if(*location >= 8){ // 放在large buf
        *target = &buffer[LARGE_START + LARGE_ELEMENT_SIZE* ((*location)-8)];
    }else{
        *target = &buffer[SMALL_ELEMENT_SIZE* (*location)];
    }
}

/**
 * 無空間回傳-1 否則回傳可放置的起始位置
 */
int test_location(int type)
{
    unsigned char mask = 1;
    int location = 0;
    if(type == 1){// small node
        for (int i = 0; i < NUM_SMALL_BYTE_BUF; i++) // 檢查small_buf是否有空間
        {
            if((byte_small_buf_mask & mask) != 0)
            {
                mask = mask << 1;
                location ++;
            }else{
                return location;
            }
        }
        location = 8;// large location start
        mask = 1;
        for (int i = 0; i < NUM_LARGE_BYTE_BUF; i++) // 檢查large_buf是否有空間
        {
            if((byte_large_buf_mask & mask) != 0)
            {
                mask = mask << 1;
                location ++;
            }else{
                return location;
            }
        }
    }else{ //large node
        unsigned char mask = 1;
        location = 8;// large location start
        for (int i = 0; i < NUM_LARGE_BYTE_BUF; i++) // 檢查large_buf是否有空間
        {
            if((byte_large_buf_mask & mask) != 0)
            {
                mask = mask << 1;
                location ++;
            }else{
                return location;
            }
        }
        mask = 3;// large node 放在small buf要佔2bytes
        location = 0;// small location start
        for (int i = 0; i < NUM_SMALL_BYTE_BUF-1; i++) // 檢查small_buf是否有空間
        {
            if((byte_small_buf_mask & mask) != 0)
            {
                mask = mask << 1;
                location ++;
            }else{
                return location;
            }
        }
        
    }
    
    return -1;
}

void set_bit(int location, int type)
{
    unsigned char mask;
    int move;// 位移量
    if(location >= 8){ // 放在large buf
        mask = 1;// large buf 不管大小node都佔1byte
        mask = mask << (location - 8);
        byte_large_buf_mask = byte_large_buf_mask | mask;
    }else{
        mask = (type == 1)? 1:3; // small buf 大node佔2bytes
        mask = mask << location;
        byte_small_buf_mask = byte_small_buf_mask | mask;
    }
    
    
}

void our_free(int location, int type)
{
    unsigned char mask = 1;
    if(location >= 8){// large_buf
        mask = mask << (location-8);
        byte_large_buf_mask = byte_large_buf_mask & (~mask);
    }else{
        mask = (type == 1)? 1 : 3; // small buf 大node佔2bytes
        mask = mask << location;
        byte_small_buf_mask = byte_small_buf_mask & (~mask);
    }
}
