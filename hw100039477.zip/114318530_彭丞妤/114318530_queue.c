#include "queue.h"
#include "space.h"

int tqueue_enqueue(tQueue *queue, int id, int score, int type){
    tQueueNode *queue_node;
    void *newptr = NULL;
    int mem_location;
    
    queue_node = (tQueueNode *)malloc(sizeof(tQueueNode));
    our_malloc (type, (void *)&newptr, &mem_location);// 挖空間給newptr

    if (newptr == NULL){
        printf("    Enqueue Failed !!! \n\n");
        return 0;
    }
    if(type == 1){// 判斷是大小node, newptr放值
        tQueueSmall *node = (tQueueSmall *)newptr;
        node->id = id;
        node->score = score;
        node->location = mem_location;
    }else{
        tQueueLarge *node = (tQueueLarge *)newptr;
        node->id = id;
        node->score[0] = score;
        node->location = mem_location;
    }
    queue_node->type = type;
    queue_node->content = newptr;
    queue_node->next = NULL;
    queue_node->prev = NULL;

    if(queue->count == 0){
        queue->front = queue_node;
        queue->rear = queue_node;
    }else{
        queue_node->prev = queue->rear;
        queue->rear->next = queue_node;
        queue->rear = queue_node;
    }
    queue->count ++;
    return 1;
}

tQueue* createQueue(void){    
    tQueue *queue;
    queue=(tQueue *) malloc (sizeof(tQueue));

    if (queue)
    {
        queue->front=NULL;
        queue->rear=NULL;  
        queue->count=0;
    }

    return queue;
}

void print_target_info(tQueueNode **target, int type)
{
    int loc;
    int id;
    if(type == 1){
        tQueueSmall *node = (tQueueSmall *)((*target)->content);
        loc = node->location;
        id = node->id;
    }else{
        tQueueLarge *node = (tQueueLarge *)((*target)->content);
        loc = node->location;
        id = node->id;
    }
    printf(" target type: %d, location: %d, id: %d\n",type, loc, id);

    tQueueNode *next_node = (*target)->next;
    if(next_node != NULL){
        int next_type = next_node->type;
        if(next_type == 1){
            tQueueSmall *node = (tQueueSmall *)(next_node->content);
            loc = node->location;
            id = node->id;
        }else{
            tQueueLarge *node = (tQueueLarge *)(next_node->content);
            loc = node->location;
            id = node->id;
        }
        printf(" target next type: %d, location: %d, id: %d\n",next_type, loc, id);
    }else{
        printf(" no target next\n");
    }
}

void dequeue_node(tQueue **queue, tQueueNode **target, int type)
{
    if((*queue)->count == 1){
        (*queue)->front = NULL;
        (*queue)->rear = NULL;
    }else{

        if ((*queue)->front == (*target)) // 頭
        {
            (*queue)->front = (*target)->next;
            (*target)->next->prev = NULL;
        }
        else if ((*queue)->rear == (*target)) // 尾
        {
            (*queue)->rear = (*target)->prev;
            (*target)->prev->next = NULL;
        }
        else{
            (*target)->prev->next = (*target)->next;
            (*target)->next->prev = (*target)->prev;
        }

    }

    (*queue)->count--;
    if(type == 1){
        tQueueSmall *node = (tQueueSmall *)((*target)->content);
        our_free(node->location, type);
    }else{
        tQueueLarge *node = (tQueueLarge *)((*target)->content);
        our_free(node->location, type);
    }
}

tQueueNode *find_target_node(tQueue **queue, int id, int type)
{
    tQueueNode *target = (*queue)->front;
    while ( target != NULL )
    {
        if(target->type == type){ // check type
            if(type == 1){
                tQueueSmall *node = (tQueueSmall *)target->content;
                if(node->id == id){ //check id
                    return target;
                }
            }else{
                 tQueueLarge *node = (tQueueLarge *)target->content;
                if(node->id == id){
                    return target;
                }
            }
        }
        target = target->next;
    }

    return NULL;
}


void print_queue (tQueue **queue)
{
    int i;
    tQueueNode *target = (*queue)->front;

    printf("      type mixed queue: ");    
    for (i = 0; i < (*queue)->count; i++)
    {
        int Qtype = target->type;
        if(Qtype == 1){
            tQueueSmall *q = (tQueueSmall *)target->content;
            printf ("%d,%d(%d,%d) ", q->id, q->score, Qtype, q->location);
        }else{
            tQueueLarge *q = (tQueueLarge *)target->content;
            printf ("%d,%d(%d,%d) ", q->id, q->score[0], Qtype, q->location);
        }
        
        target = target->next;
    }
    printf("\n\n");
}