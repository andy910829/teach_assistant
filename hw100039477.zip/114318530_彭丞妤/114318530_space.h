#ifndef __SPACE__
#define __SPACE__

#include "main.h"

#define NUM_SMALL_BYTE_BUF      8
#define NUM_LARGE_BYTE_BUF      8

#define SMALL_ELEMENT_SIZE      32
#define LARGE_ELEMENT_SIZE      64
#define LARGE_START             (SMALL_ELEMENT_SIZE*NUM_SMALL_BYTE_BUF)

void print_buffer_status(void);
void our_malloc(int size, void **target, int *location);
void our_free(int location, int type);  
int test_location(int type);
void set_bit(int location, int type);

#endif