#include "queue.h"
#include "space.h"
#include <stdio.h>
#include <stdlib.h>

tQueue* createQueue(void){    
    tQueue *queue;
    queue=(tQueue *) malloc (sizeof(tQueue));

    if (queue)
    {
        queue->front=NULL;
        queue->rear=NULL;  
        queue->count=0;
    }

    return queue;
}

int tqueue_enqueue(tQueue *queue, int type, int id, int score)
{
    tQueueNode *queue_node;
    void *newptr = NULL;
    int mem_location;
    tQueueSmall *small_content;
    tQueueLarge *large_content;

    if (queue == NULL)
    {
        return 0;
    }

    // 先分配節點記憶體
    queue_node = (tQueueNode *)malloc(sizeof(tQueueNode));
    if (queue_node == NULL)
    {
        return 0;
    }

    // 分配資料記憶體
    our_malloc(type, (void **)&newptr, &mem_location);
    
    if (newptr == NULL)
    {
        printf("    Enqueue Failed !!! \n");
        printf("\n");
        free(queue_node);
        return 0;
    }
    
    // 根據 type 分配對應的 content 結構
    if (type == 1)  // type 1: small
    {
        small_content = (tQueueSmall *)newptr;
        small_content->id = id;
        small_content->score = score;
        small_content->location = mem_location;
        queue_node->content = (void *)small_content;
    }
    else if (type == 2)  // type 2: large
    {
        large_content = (tQueueLarge *)newptr;
        large_content->id = id;
        large_content->score[0] = score;  // 將 score 存第一
        large_content->location = mem_location;
        queue_node->content = (void *)large_content;
    }
    
    queue_node->type = type;
    queue_node->next = NULL;
    queue_node->prev = NULL;
    
    if (queue->front == NULL)
    {
        queue->front = queue_node;
        queue->rear = queue_node;
    }
    else
    {
        queue->rear->next = queue_node;
        queue_node->prev = queue->rear;
        queue->rear = queue_node;
    }

    queue->count++;
    
    return 1;
}

void tqueue_dequeue(tQueue *queue, tQueueNode *target)
{
    tQueueSmall *small_content;
    tQueueLarge *large_content;
    int mem_location;

    if (queue == NULL || target == NULL || queue->count == 0)
    {
        return;
    }

    // 取得 location 和 id
    if (target->type == 1)
    {
        small_content = (tQueueSmall *)target->content;
        mem_location = small_content->location;
        printf("target type: %d, location: %d, id: %d\n", target->type, mem_location, small_content->id);
    }
    else if (target->type == 2)
    {
        large_content = (tQueueLarge *)target->content;
        mem_location = large_content->location;
        printf("target type: %d, location: %d, id: %d\n", target->type, mem_location, large_content->id);
    }

    if (target->next != NULL)
    {
        if (target->next->type == 1)
        {
            small_content = (tQueueSmall *)target->next->content;
            printf("target next type: %d, location: %d, id: %d\n", 
                   target->next->type, small_content->location, small_content->id);
        }
        else if (target->next->type == 2)
        {
            large_content = (tQueueLarge *)target->next->content;
            printf("target next type: %d, location: %d, id: %d\n", 
                   target->next->type, large_content->location, large_content->id);
        }
    }

    if (target == queue->front)
    {
        queue->front = target->next;
        if (queue->front != NULL)
        {
            queue->front->prev = NULL;
        }
        else
        {
            queue->rear = NULL;
        }
    }
    else if (target == queue->rear)
    {
        queue->rear = target->prev;
        if (queue->rear != NULL)
        {
            queue->rear->next = NULL;
        }
        else
        {
            queue->front = NULL;
        }
    }
    else
    {
        if (target->prev != NULL)
        {
            target->prev->next = target->next;
        }
        if (target->next != NULL)
        {
            target->next->prev = target->prev;
        }
    }

    target->next = NULL;
    target->prev = NULL;

    queue->count--;
    
    // 釋放記憶體：先釋放 content 指向的 buffer，再釋放節點本身
    if (target->type == 1)
    {
        small_content = (tQueueSmall *)target->content;
        our_free(small_content->location, target->type);
    }
    else if (target->type == 2)
    {
        large_content = (tQueueLarge *)target->content;
        our_free(large_content->location, target->type);
    }
    
    free(target);
}

tQueueNode *find_target_node(tQueue *queue, int type, int id)
{
    int i;
    tQueueNode *target;
    tQueueSmall *small_content;
    tQueueLarge *large_content;

    if (queue == NULL || queue->count == 0)
    {
        return NULL;
    }

    target = queue->front;

    for (i = 0; i < queue->count && target != NULL; i++)
    {
        if (target->type == type)
        {
            if (type == 1)
            {
                small_content = (tQueueSmall *)target->content;
                if (small_content->id == id)
                {
                    return target;
                }
            }
            else if (type == 2)
            {
                large_content = (tQueueLarge *)target->content;
                if (large_content->id == id)
                {
                    return target;
                }
            }
        }
        target = target->next;
    }

    return NULL;
}

void print_queue (tQueue *queue)
{
    tQueueNode *target = queue->front;
    tQueueSmall *small_content;
    tQueueLarge *large_content;

    printf("      type mixed queue: ");    
    while (target != NULL)
    {
        if (target->type == 1)
        {
            small_content = (tQueueSmall *)target->content;
            printf("%d,%d(%d,%d) ", small_content->id, small_content->score, target->type, small_content->location);
        }
        else if (target->type == 2)
        {
            large_content = (tQueueLarge *)target->content;
            printf("%d,%d(%d,%d) ", large_content->id, large_content->score[0], target->type, large_content->location);
        }
        target = target->next;
    }
    printf("\n");
}
