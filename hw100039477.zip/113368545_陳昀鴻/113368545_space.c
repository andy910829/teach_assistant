#include "space.h"
#include <stdio.h>

unsigned char buffer[SMALL_ELEMENT_SIZE * NUM_SMALL_BYTE_BUF + LARGE_ELEMENT_SIZE * NUM_LARGE_BYTE_BUF];

unsigned char byte_small_buf_mask = 0;  // bit 0-7 對應 location 0-7
unsigned char byte_large_buf_mask = 0;  // bit 0-7 對應 location 8-15

// 檢查 small buffer 中是否有空位
static int check_small_buffer_available(int location)
{
    if (location < 0 || location >= NUM_SMALL_BYTE_BUF)
        return 0;
    
    int bit_pos = location;
    return ((byte_small_buf_mask >> bit_pos) & 1) == 0;
}

// 檢查 large buffer 中是否有空位
static int check_large_buffer_available(int location)
{
    if (location < NUM_SMALL_BYTE_BUF || location >= NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)
        return 0;
    
    int bit_pos = location - NUM_SMALL_BYTE_BUF;
    return ((byte_large_buf_mask >> bit_pos) & 1) == 0;
}

// 設定 small buffer 的 bit
static void set_small_buffer_bit(int location)
{
    if (location >= 0 && location < NUM_SMALL_BYTE_BUF)
    {
        int bit_pos = location;
        byte_small_buf_mask |= (1 << bit_pos);
    }
}

// 設定 large buffer 的 bit
static void set_large_buffer_bit(int location)
{
    if (location >= NUM_SMALL_BYTE_BUF && location < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)
    {
        int bit_pos = location - NUM_SMALL_BYTE_BUF;
        byte_large_buf_mask |= (1 << bit_pos);
    }
}

// 清除 small buffer 的 bit
static void clear_small_buffer_bit(int location)
{
    if (location >= 0 && location < NUM_SMALL_BYTE_BUF)
    {
        int bit_pos = location;
        byte_small_buf_mask &= ~(1 << bit_pos);
    }
}

// 清除 large buffer 的 bit
static void clear_large_buffer_bit(int location)
{
    if (location >= NUM_SMALL_BYTE_BUF && location < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF)
    {
        int bit_pos = location - NUM_SMALL_BYTE_BUF;
        byte_large_buf_mask &= ~(1 << bit_pos);
    }
}

void print_buffer_status(void)
{
    printf("      byte_small_buf_mask: ");
    // 從 bit 7 到 bit 0 (從左到右)
    for (int i = 7; i >= 0; i--)
    {
        printf("%d ", (byte_small_buf_mask >> i) & 1);
    }
    printf("\n");
    
    printf("      byte_large_buf_mask: ");
    // 從 bit 7 到 bit 0 (從左到右)
    for (int i = 7; i >= 0; i--)
    {
        printf("%d ", (byte_large_buf_mask >> i) & 1);
    }
    printf("\n");
}

int get_remaining_space(void)
{
    int count = 0;
    
    // 計算 small buffer 剩餘空間
    for (int i = 0; i < NUM_SMALL_BYTE_BUF; i++)
    {
        if (((byte_small_buf_mask >> i) & 1) == 0)
            count++;
    }
    
    // 計算 large buffer 剩餘空間
    for (int i = 0; i < NUM_LARGE_BYTE_BUF; i++)
    {
        if (((byte_large_buf_mask >> i) & 1) == 0)
            count++;
    }
    
    return count;
}

// type: 1 for small, 2 for large
// newptr: 分配的記憶體地址（輸出參數）
// mem_location: 分配的記憶體起始位置 (0-15)（輸出參數）
void our_malloc(int type, void **newptr, int *mem_location)
{
    int i;
    
    if (type == 1)  // type 1: 小東西
    {
        // 優先使用 small buffer (0-7)
        for (i = 0; i < NUM_SMALL_BYTE_BUF; i++)
        {
            if (check_small_buffer_available(i))
            {
                set_small_buffer_bit(i);
                *mem_location = i;
                *newptr = (void *)(buffer + i * SMALL_ELEMENT_SIZE);
                return;
            }
        }
        
        // small buffer 滿了，使用 large buffer (8-15)
        for (i = NUM_SMALL_BYTE_BUF; i < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF; i++)
        {
            if (check_large_buffer_available(i))
            {
                set_large_buffer_bit(i);
                *mem_location = i;
                *newptr = (void *)(buffer + LARGE_START + (i - NUM_SMALL_BYTE_BUF) * LARGE_ELEMENT_SIZE);
                return;
            }
        }
    }
    else if (type == 2)  // type 2: 大東西
    {
        // 優先使用 large buffer (8-15)
        for (i = NUM_SMALL_BYTE_BUF; i < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF; i++)
        {
            if (check_large_buffer_available(i))
            {
                set_large_buffer_bit(i);
                *mem_location = i;
                *newptr = (void *)(buffer + LARGE_START + (i - NUM_SMALL_BYTE_BUF) * LARGE_ELEMENT_SIZE);
                return;
            }
        }
        
        // large buffer 滿了，使用 small buffer (0-7)，以2個單位為單位
        for (i = 0; i <= NUM_SMALL_BYTE_BUF - 2; i++)
        {
            // 檢查連續的 2 個空位
            if (check_small_buffer_available(i) && check_small_buffer_available(i + 1))
            {
                set_small_buffer_bit(i);
                set_small_buffer_bit(i + 1);
                *mem_location = i;
                *newptr = (void *)(buffer + i * SMALL_ELEMENT_SIZE);
                return;
            }
        }
    }
    
    // 找不到可用空間
    *newptr = NULL;
    *mem_location = -1;
}

void our_free(int mem_location, int type)
{
    if (mem_location < 0)
        return;
    
    // 小空間的判斷
    if (mem_location < NUM_SMALL_BYTE_BUF)
    {
        // type 2 在 small buffer 中佔用 2 個單位
        if (type == 2)
        {
            clear_small_buffer_bit(mem_location);
            if (mem_location + 1 < NUM_SMALL_BYTE_BUF)
            {
                clear_small_buffer_bit(mem_location + 1);
            }
        }
        else
        {
            // type 1 只佔用 1 個單位
            clear_small_buffer_bit(mem_location);
        }
    }
    else if (mem_location < NUM_SMALL_BYTE_BUF + NUM_LARGE_BYTE_BUF) // 大空間的判斷
    {
        // type 2 在 large buffer 中只佔用 1 個單位
        clear_large_buffer_bit(mem_location);
    }
}
