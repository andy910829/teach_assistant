#ifndef __SPACE__
#define __SPACE__

#include "main.h"

#define NUM_SMALL_BYTE_BUF 8
#define NUM_LARGE_BYTE_BUF 8

#define SMALL_ELEMENT_SIZE 32
#define LARGE_ELEMENT_SIZE 64

#define LARGE_START (SMALL_ELEMENT_SIZE*NUM_SMALL_BYTE_BUF)


void print_buffer_status(void);
int get_remaining_space(void);
// type: 1 for small, 2 for large
// newptr: 分配的記憶體地址（輸出參數）
// mem_location: 分配的記憶體起始位置 (0-15)（輸出參數）
void our_malloc(int type, void **newptr, int *mem_location);
void our_free(int mem_location, int type);  

#endif