#ifndef __QUEUE__
#define __QUEUE__

typedef struct type_small {
    int id;
    int location;
    int score;
} tQueueSmall;

typedef struct type_large {
    int id;
    int location;
    int score[8];
} tQueueLarge;

typedef struct node_info {
    int type;
    void *content;
    struct node_info *next;
    struct node_info *prev;
} tQueueNode;

typedef struct {
    tQueueNode *front; // queue 的 front 指標
    tQueueNode *rear; // queue 的 rear 指標
    int count; // queue 中的節點數量
}tQueue;


tQueue* createQueue(void);

int tqueue_enqueue(tQueue *queue, int type, int id, int score);
void tqueue_dequeue(tQueue *queue, tQueueNode *target);
tQueueNode *find_target_node(tQueue *queue, int type, int id);

void print_queue(tQueue *queue);

#endif