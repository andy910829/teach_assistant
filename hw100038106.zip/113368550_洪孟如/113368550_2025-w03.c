//hello.c

#include <stdio.h>
#include <stdlib.h>


typedef struct nume_list
{
	int counts;
	int *p_list;
}tNumList;


void fill_list(tNumList *list, int id);
void bubble_sort(tNumList *list, int id);
void merge(tNumList *list1, tNumList *list2);
void printf_list(tNumList *list);

int main(){
	tNumList *list1, *list2;
	list1 = (tNumList*)malloc(sizeof(tNumList));
	list2 = (tNumList*)malloc(sizeof(tNumList));
	
	fill_list(list1, 1);
	fill_list(list2, 2);
	
	
	printf("\n");
	
	bubble_sort(list1, 1);
	bubble_sort(list2, 2);
	
	merge(list1, list2);
	
	return 0;
}

void fill_list(tNumList *list, int id)
{
	printf("Please enter how many numers in list%d: ",id);
	scanf("%d",&list->counts);

	list->p_list = (int *) malloc (sizeof(int)*(list->counts));
	printf("   Please input %d numbers: ",list->counts);
	
	for(int i=0;i<list->counts;i++){
		scanf("%d",&list->p_list[i]);
	}
}

void bubble_sort(tNumList *list, int id)
{
	for(int i = list->counts-1; i > 0; i-- )
	{
		for(int j=0; j<list->counts-1; j++)
		{
			if((list->p_list[j])>(list->p_list[j+1]))
			{
				int tmp = list->p_list[j];
				list->p_list[j] = list->p_list[j+1];
				list->p_list[j+1] = tmp;
			}
		}
	}
	
	printf("sorted list%d: ",id);
	printf_list(list);
	printf("\n");
}

void merge(tNumList *list1, tNumList *list2)
{
	printf("merged list: ");
	
	int offset=0;
	for(int i=0; i<list1->counts; i++)
	{
		for(int j=offset;j<list2->counts;j++)
		{
			if(list1->p_list[i]>=list2->p_list[j]){
				printf("%d ",list2->p_list[j]);
				offset= j+1;
			}
		}
		printf("%d ",list1->p_list[i]);
	}

	printf("\n");
}
void printf_list(tNumList *list)
{
	for(int i=0; i<list->counts; i++)
	{
		printf(" %d", list->p_list[i]);
	}
}