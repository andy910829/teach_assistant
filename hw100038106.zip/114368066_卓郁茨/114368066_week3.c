#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
    int counts;
    int *p_list;
}tNumList;

void fill_list(tNumList *list);
void bubble_sort(tNumList *list);
void merge(tNumList *list1, tNumList *list2);
void print_list(tNumList *list);

int main(void)
{
    tNumList *list1, *list2;
    
    // printf("please enter how many numbers in list1:");
    // fill_list(list1);
    // list1 = (tNumList *) malloc (sizeof(tNumList));
    list1 = (tNumList *) malloc(sizeof(tNumList)); // 先配置，counts會被配置4Bytes，p_list則是8Bytes
    printf("please enter how many numbers in list1: ");
    fill_list(list1);
    bubble_sort(list1);
    printf("sorted list1: ");
    print_list(list1);
    
    list2 = (tNumList *) malloc(sizeof(tNumList)); 
    printf("please enter how many numbers in list2: ");
    fill_list(list2);
    bubble_sort(list2);
    printf("sorted list2: ");
    print_list(list2);

    merge(list1, list2);

    system("pause");
    return 0;
}

void fill_list(tNumList *list)
{
    
    scanf("%d", &(list -> counts));
    printf("please input %d numbers:", (list -> counts));
    list -> p_list = (int *) malloc (list -> counts * sizeof(int));
    for(int i = 0; i < (list -> counts); i++)
    {
        scanf("%d", &(list -> p_list[i]));
    }
    // for(int i = 0; i < (list -> counts); i++)
    // {
    //     printf("%d\n", list[i].p_list);
    // }
}

void bubble_sort(tNumList *list)
{
    int elementNum = list -> counts;
    int i, j, temp;
    for (i = 0; i < (elementNum - 1); i++)
    {
        for (j = 0; j < (elementNum - i - 1); j++)
        {
            if (list -> p_list[j] > list -> p_list[j + 1])
            {
                temp = list -> p_list[j];
                list -> p_list[j] = list -> p_list[j + 1];
                list -> p_list[j + 1] = temp;
            }
        }
    }
    
}

void merge(tNumList *list1, tNumList *list2)
{
    int ind1 = 0, ind2 = 0;
    printf("merged list: ");
    while(ind1 < list1 -> counts && ind2 < list2 -> counts)
    {
        if(list1 -> p_list[ind1] <= list2 -> p_list[ind2])
        {
            printf("%d ", list1 -> p_list[ind1]);
            ind1++;
        }
        else
        {
            printf("%d ", list2 -> p_list[ind2]);
            ind2++;
        }
    }
    
    while(ind1 < list1 -> counts)
    {
        printf("%d ", list1 -> p_list[ind1]);
        ind1++;
    }

    while(ind2 < list2 -> counts)
    {
        printf("%d ", list2 -> p_list[ind2]);
        ind2++;
    }
    printf("\n");
}

void print_list(tNumList *list)
{
    int elementNum = list -> counts;
    for(int i = 0; i < elementNum; i++)
    {
        printf("%d ", list -> p_list[i]);
    }
    printf("\n");
}