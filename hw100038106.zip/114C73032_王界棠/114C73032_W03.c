#include <stdio.h>
// I/O顯示函式庫

#include<stdlib.h>
// 目前用來生記憶體

typedef struct  num_list
// 宣告一個資料結構 叫 num_list
{
    int counts;

    int* p_list;

}tNumList;
// tNumList = int的概念

void fill_list (tNumList* list);

void bubble_sor (tNumList* list);

void merge (tNumList* list1 ,tNumList* list2);

void print_list (tNumList* list);

// tNumList -> int 的概念

int main(void){

    tNumList* list1, *list2 ;
    // 兩個指標

        list1 = (tNumList*) malloc(sizeof(tNumList));
        // 只要為工單分配一個結構
            fill_list (list1);

            bubble_sor(list1);

            printf("sorted list1: ");

            print_list(list1);


        // 理解這邊的counts

        list2 = (tNumList*) malloc(sizeof(tNumList));

            fill_list (list2);

            bubble_sor(list2);

            printf("sorted list2: ");

            print_list(list2);

            printf("merged list: ");

            merge(list1,list2);


            free(list1->p_list);

            free(list2->p_list);

            free(list1);

            free(list2);
            
            return 0;

}

/*輸入指令*/

void fill_list (tNumList* list)
{
    // 這邊list 就是任意變數
   
        printf("Please enter how many number in list:" );

        scanf("%d", &(list -> counts));

        // 這邊是存入動態空間 (指標指向)

        list -> p_list = (int*) malloc ((list -> counts) * sizeof(int));
        // 指向並存入這個新的記憶體空間門牌

            for(int i = 0 ; i < (list -> counts) ; i++)
            {
               
                scanf("%d", &(list->p_list[i]));
                            //輸入對應的空間
                            //錯誤點1
            }
        
        printf("\n");

}

/*氣泡排序*/

void bubble_sor (tNumList* list)
{

    int bus = 0 ;

    for(int i = 0 ; i < (list-> counts-1) ;i++)
                        // 這邊存取不用括號 (把他當陣列來看)
    {
        for(int j = 0 ; j < (list-> counts-1 - i) ; j++)
                        // 這邊存取不用括號
        {
            if(list -> p_list[i] > list -> p_list [j+1])

            {          
                bus = list -> p_list[i];

                list -> p_list[i] = list -> p_list[j+1];

                list -> p_list [j+1] =bus; 
    
            }

        }

    }

 }

 /*組合結果
 
 寫筆記*/

void merge (tNumList* list1 ,tNumList* list2)
{

    int i = 0 ,j = 0 ;


    while ( i< (list1 -> counts) && j < (list2 -> counts))
    {
        if(list1 -> p_list [i] < list2 -> p_list[j])
        {
           printf("%d ", list1 -> p_list[i++]);

        }
        else
        {
            printf("%d ", list2 -> p_list[j++]);
        }

    }

    while (i < (list1 -> counts))
    {

        printf("%d ", list1 -> p_list[i++]);

    }
    
    while (j < (list2 -> counts))
    {

        printf("%d ", list2 -> p_list[j++]);
    }

    printf("\n");

    
}

/*顯示函數*/

void print_list (tNumList* list)
{
    for(int i = 0 ; i < list-> counts ; i++)
    {

        printf("%d ", (list-> p_list[i]));

    }
    
    printf("\n");
} 

  // 這邊是將code寫入

 // 這個是依據 tNumlist 建立對應的記憶體空間

// tNumList 就像 DB -> 當你有新增資料時，才挖記憶體
        
// 目前這個意思是 我將這塊記憶體空間 使用 list1指向他

// list -> p_list 這邊要以資料結構的角度看