#include <stdio.h>
#include <stdlib.h>

typedef struct num_list{
    int count;
    int *p_list;
}tNumList;

void fill_list(tNumList *list){
    list->p_list = (int *)malloc(sizeof(int)*list->count);
    for(int i = 0; i < list->count; i++){
        scanf("%d", &list->p_list[i]);
    }
};
void bubble_sort(tNumList *list){
    for(int i = 0; i < list->count; i++){
        for ( int j = 0; j < list->count -i -1; j++){
            if(list->p_list[j] > list->p_list[j+1]){
                int temp = list->p_list[j];
                list->p_list[j] = list->p_list[j+1];
                list->p_list[j+1] = temp;
            }
        }
    }
};
void merge (tNumList *list1, tNumList *list2){
    int idx1 = 0, idx2 = 0;
    while (idx1 < list1->count && idx2 < list2->count){
        if(list1->p_list[idx1] < list2->p_list[idx2]){
            printf("%d ", list1->p_list[idx1]);
            idx1 ++;
        }else{
            printf("%d ", list2->p_list[idx2]);
            idx2 ++;
        }
    }
    if(idx1 < list1->count){
        for(int i = idx1; i < list1->count; i++){
            printf("%d ", list1->p_list[i]);
        }
    }else{
        for(int i = idx2; i < list2->count; i++){
            printf("%d ", list2->p_list[i]);
        }
    }
    printf("\n");
}
void print_list(tNumList *list){
    for(int i = 0;i < list->count; i++){
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
}

int main(){
    tNumList *list1, *list2;
    list1 = (tNumList *) malloc(sizeof(tNumList));
    list2 = (tNumList *) malloc(sizeof(tNumList));
    printf("Please enter how many numbers in list1: ");
    scanf("%d", &list1->count);
    printf("     Please input %d numbers:", list1->count);
    fill_list(list1);

    printf("Please enter how many numbers in list2: ");
    scanf("%d", &list2->count);
    printf("     Please input %d numbers:", list2->count);
    fill_list(list2);

    printf("sorted list1: ");
    bubble_sort(list1);
    print_list(list1);
    printf("sorted list2: ");
    bubble_sort(list2);
    print_list(list2);

    printf("merge list: ");
    merge(list1, list2);

    free(list1->p_list);
    free(list2->p_list);
    free(list1);
    free(list2);
    return 0;
}