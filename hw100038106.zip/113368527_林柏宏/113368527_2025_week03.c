#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
    int counts;
    int *pList;
} tNumList;

// 檢查輸入暫存區是否為空
int is_input_buffer_empty()
{
    int c = getchar();
    if (c == EOF) return 1;
    ungetc(c, stdin); // 將字元放回輸入暫存區
    return (c == '\n');
}

// 清除輸入暫存區非數字字元
void clear_nonnumber_buffer()
{
    printf("    Skip input: ");
    int c = getchar();
    while(((c < '0') || (c > '9')) &&
          (c != '\n') && (c != EOF))
    {
        printf("%c", c);
        c = getchar();
    }
    ungetc(c, stdin); // 將字元放回輸入暫存區
    printf("\n");
}

void fill_list(tNumList *pList)
{
    if(!scanf("%d", &(pList->counts)))
    {
        clear_nonnumber_buffer();
    }
    if(pList->counts <= 0)
    {
        printf("    Skip input numbers in list!\n");
        return;
    }
    printf("    There are %d numbers in list!\n", pList->counts);

    pList->pList = malloc(sizeof(int)*(pList->counts));

    for(int i = 0; i < (pList->counts); i++)
    {
        if(is_input_buffer_empty())
        {
            if(i > 0)
            {
                printf("    list: ");
            }
            for(int j = 0; j < i; j++)
            {
                printf("%d ", pList->pList[j]);
            }
            printf("\n    Please input %d numbers: ", (pList->counts - i));
        }
        if(!scanf("%d", &(pList->pList[i])))
        {
            clear_nonnumber_buffer();
            i--;
        }
    }
    printf("\n");
}

void bubble_sort(tNumList *pList)
{
    if(pList->counts <= 0)
    {
        return;
    }

    for(int i = 0; i < (pList->counts)-1; i++)
    {
        for(int j = i+1; j < (pList->counts); j++)
        {
            if(pList->pList[i] > pList->pList[j])
            {
                int tmp = pList->pList[i];
                pList->pList[i] = pList->pList[j];
                pList->pList[j] = tmp;
            }
        }
    }
}

void merge(tNumList *pList1, tNumList *pList2)
{
    if((pList1->counts <= 0) && (pList2->counts <= 0))
    {
        return;
    }

    printf("Merged list: ");
    int i1 = 0, i2 = 0;
    while((i1 < pList1->counts) || (i2 < pList2->counts))
    {
        // 指示要填哪個list
        char fPrint = 0x00;
        if((i1 < pList1->counts) && (i2 < pList2->counts))
        {
            if(pList1->pList[i1] < pList2->pList[i2])
            {
                fPrint |= 0x01; // list 1較小填list1
            }
            else if(pList1->pList[i1] > pList2->pList[i2])
            {
                fPrint |= 0x10; // list 2較小填list2
            }
            else
            {
                fPrint |= 0x11; // list1 & list2一樣都填
            }
        }
        else if(i1 < pList1->counts)
        {
            fPrint |= 0x01; // 只剩list 1填list1
        }
        else // if(i2 < pList2->counts)
        {
            fPrint |= 0x10; // 只剩list 2填list2
        }

        if(fPrint & 0x01)
        {
            printf("%d ", pList1->pList[i1]);
            i1++;
        }
        if(fPrint & 0x10)
        {
            printf("%d ", pList2->pList[i2]);
            i2++;
        }
    }
    printf("\n");
}

void print_list(tNumList *pList)
{
    for(int i = 0; i < (pList->counts); i++)
    {
        printf("%d ", pList->pList[i]);
    }
    printf("\n");
}

int main()
{
    tNumList *list1, *list2;
    list1 = malloc(sizeof(tNumList));
    list2 = malloc(sizeof(tNumList));

    printf("All non-numeric characters will be skipped!\n");

    printf("Please enter how many numbers in list1: ");
    fill_list(list1);
    // printf("list1: ");
    // print_list(list1);
    printf("Please enter how many numbers in list2: ");
    fill_list(list2);
    // printf("list2: ");
    // print_list(list2);

    bubble_sort(list1);
    printf("Sorted list1: ");
    print_list(list1);
    bubble_sort(list2);
    printf("Sorted list2: ");
    print_list(list2);

    merge(list1, list2);

    return 0;
}