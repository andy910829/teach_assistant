#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
    int counts;
    int *p_list;
} tNumList;

void fill_list(tNumList *list, const char *name)
{
    int i;
    printf("Please enter how many numbers in %s: ", name);
    scanf("%d", &list->counts);

    list->p_list = (int *)malloc(sizeof(int) * list->counts);

    printf("Please input %d numbers for %s: ", list->counts, name);
    for (i = 0; i < list->counts; i++)
    {
        scanf("%d", &list->p_list[i]);
    }
}

void bubble_sort(tNumList *list)
{
    int i, j;
    for (i = 0; i < list->counts - 1; i++)
    {
        for (j = 0; j < list->counts - i - 1; j++)
        {
            if (list->p_list[j] > list->p_list[j + 1])
            {
                int temp = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = temp;
            }
        }
    }
};

void merge(tNumList *list1, tNumList *list2)
{
    // 基本防呆：如果其中一個 list 為空或尚未配置記憶體
    if (!list1 || !list2)
    {
        printf("merge error: null list pointer.\n");
        return;
    }
    if (list1->counts < 0 || list2->counts < 0)
    {
        printf("merge error: invalid counts.\n");
        return;
    }
    if ((list1->counts > 0 && list1->p_list == NULL) ||
        (list2->counts > 0 && list2->p_list == NULL))
    {
        printf("merge error: list has no data buffer.\n");
        return;
    }

    // 建立合併後的新清單（僅在此函式中使用，不改動原本兩個 list）
    tNumList merged;
    merged.counts = list1->counts + list2->counts;
    merged.p_list = (int *)malloc(sizeof(int) * merged.counts);
    if (!merged.p_list)
    {
        printf("merge error: memory allocation failed.\n");
        return;
    }

    // 兩指標法：i 走訪 list1，j 走訪 list2，k 寫入 merged
    int i = 0, j = 0, k = 0;

    // 因為 list1、list2 在呼叫前已各自 bubble_sort()，所以可直接線性合併
    while (i < list1->counts && j < list2->counts)
    {
        if (list1->p_list[i] <= list2->p_list[j])
        {
            merged.p_list[k++] = list1->p_list[i++];
        }
        else
        {
            merged.p_list[k++] = list2->p_list[j++];
        }
    }

    // 若 list1 尚有剩餘元素，全部接到 merged 後面
    while (i < list1->counts)
    {
        merged.p_list[k++] = list1->p_list[i++];
    }
    // 若 list2 尚有剩餘元素，全部接到 merged 後面
    while (j < list2->counts)
    {
        merged.p_list[k++] = list2->p_list[j++];
    }

    // 輸出合併結果
    printf("merged:\n");
    for (int x = 0; x < merged.counts; x++)
    {
        printf("%d ", merged.p_list[x]);
    }
    printf("\n");

    // 釋放在本函式中配置的暫存合併陣列
    free(merged.p_list);
}

void print_list(tNumList *list)
{
    for (int i = 0; i < list->counts; i++)
    {
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
}

int main(void)
{
    tNumList *list1, *list2;

    list1 = (tNumList *)malloc(sizeof(tNumList));
    list2 = (tNumList *)malloc(sizeof(tNumList));

    fill_list(list1, "list1");
    fill_list(list2, "list2");

    bubble_sort(list1);
    bubble_sort(list2);

    printf("list1:\n");
    print_list(list1);
    printf("list2:\n");
    print_list(list2);

    merge(list1, list2);

    return 0;
}