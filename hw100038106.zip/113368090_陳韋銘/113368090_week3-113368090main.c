/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h> // call malloc & free
//https://groangao.pixnet.net/blog/post/24474489
typedef struct num_list {
    int cnts;
    int *p_list;
} CSGO;
//(Function Prototypes)讓 main 函式知道這些函式存在
void fill_list(CSGO *list);
void bubble_sort(CSGO *list);
void merge(CSGO *lt1, CSGO *lt2);
void print_list(CSGO *list);

int main(void) {
    // 2指標 指 CSGO struc的指標
    CSGO *lt1, *lt2;

  // sizeof(CSGO) 會計算 CSGO 這個結構用多少DDR
    lt1 = (CSGO *)malloc(sizeof(CSGO));
    lt2 = (CSGO *)malloc(sizeof(CSGO));

    // 呼叫函式 填滿串列
    fill_list(lt1);
    fill_list(lt2); 

    bubble_sort(lt1); // 排序串列
    bubble_sort(lt2); 
    printf("sorted lt1: ");
    print_list(lt1);

    printf("sorted lt2: ");
    print_list(lt2);

    // 合併結果
    printf("merged list: ");
    merge(lt1, lt2);

    // 釋放記憶體，避免 memory leak https://blog.gtwang.org/programming/c-memory-functions-malloc-free/
    // 順序!!重點!! 先釋放結構裡面的 p_list，再釋放結構本身
    free(lt1->p_list);
    free(lt1);
    free(lt2->p_list);
    free(lt2);

    return 0;
}

/**
 *  * doxygen產生文件的工具未來記得回來使用看看
 * https://hackmd.io/@ichunlai/H1R9YD0B4
 * @brief 填充串列的內容
 * @param list 指向要被填充的 CSGO 結構的指標
 */
void fill_list(CSGO *list) {
    printf("Please enter how many numbers in list: ");
    // 輸入數字存結構的 cnts 中
    scanf("%d", &list->cnts);

    // 一輸入隻數量，動態配置DDR給 p_list
    // list->cnts * sizeof(int) 計算出總共要how, much DDR
    list->p_list = (int *)malloc(list->cnts * sizeof(int));

    printf("Please input %d numbers: ", list->cnts);

    for (int i = 0; i < list->cnts; i++) {
        // list數存入 p_list 指DDR當中
        // 陣列存法 gemini教的 list->p_list[i]
        scanf("%d", &list->p_list[i]);
    }
}

/**
 * doxygen產生文件的工具未來記得回來使用看看
 * https://hackmd.io/@ichunlai/H1R9YD0B4
 * @brief 氣泡排序法 (Bubble Sort) 排串列
 * @param list 指向要被排序的 CSGO 結構的指標
 */
void bubble_sort(CSGO *list) {
    int i, j, ijsw;
    // i,j迴圈變數 ijsw站存位置第一圈決定要跑幾次 第二圈兩兩筆倆倆交換，前數字比後大就交換
    for (i = 0; i < list->cnts - 1; i++) {
        for (j = 0; j < list->cnts - i - 1; j++) {
            if (list->p_list[j] > list->p_list[j + 1]) {
                ijsw = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = ijsw;
            }
        }
    }
}

/**
 * @brief 印出串列的所有內容
 * @param list 指向要被印出的 CSGO 結構的指標
 */
void print_list(CSGO *list) {
    // for 當掃描器
    for (int i = 0; i < list->cnts; i++) {
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
}


/**
 * @brief (直接印出) 合併兩個已排序的串列
 * @param lt1 指第一串列的指標
 * @param lt2 指第二串指標
 * @note 題目要求，函式不能建新 list，要職print 結果。
 */
void merge(CSGO *lt1, CSGO *lt2) {
    int i = 0; // 追蹤 lt1 的索引
    int j = 0; // 追蹤 lt2 的索引

    // 當兩個串列還有數字時比較
    while (i < lt1->cnts && j < lt2->cnts) {
        // 比兩串列目前索引的數，並印較小者
        if (lt1->p_list[i] < lt2->p_list[j]) {
            printf("%d ", lt1->p_list[i]);
            i++; // lt1索引往前
        } else {
            printf("%d ", lt2->p_list[j]);
            j++; // lt2索引往前
        }
    }

    // 印出lt1剩餘數字
    while (i < lt1->cnts) {
        printf("%d ", lt1->p_list[i]);
        i++;
    }

    // 印出lt2剩餘數字
    while (j < lt2->cnts) {
        printf("%d ", lt2->p_list[j]);
        j++;
    }
    printf("\n");
}