#include <stdio.h>
#include <stdlib.h>

typedef struct num_list{
  int counts;
  int *p_list;
}tNumList;
void fill_list(tNumList *list)
{
    for(int i=0;i<list->counts;i++)
    {
        scanf("%d",&list->p_list[i]);
    }
}
void bubble_sort(tNumList *list)
{
    //int nums[], int length
    for(int i=list->counts-1; i>=0; i--){

        int has_sorted = 0;

        for(int j=0; j<i; j++){
            if(list->p_list[j] > list->p_list[j+1]){

                // swap elements
                int temp = list->p_list[j];
                list->p_list[j] = list->p_list[j+1];
                list->p_list[j+1] = temp;

                has_sorted = 1;
            }
        }

        if(has_sorted == 0){
            break;
        }
    }
}
void merge(tNumList *list1,tNumList *list2)
{
    int count=0;
    printf("merged list:");
    for(int i=0;i<list1->counts;i++)
    {
        while (count<list2->counts && list2->p_list[count]<=list1->p_list[i])
        {
            printf("%d ",list2->p_list[count]);
            count++;
        }
        
        printf("%d ",list1->p_list[i]);
    }
    for(int i=count;i<list2->counts;i++)
        printf("%d ",list2->p_list[i]);
}
void print_list(tNumList *list)
{
    for(int i=0;i<list->counts;i++)
    {
        printf("%d ",list->p_list[i]);
    }
}
int main()
{
    tNumList *list1,*list2;
    list1 = (tNumList*) malloc (sizeof(tNumList));
    list2 = (tNumList*) malloc (sizeof(tNumList));
    printf("Please enter how many numbers in list1:");
    scanf("%d",&list1->counts);
    list1->p_list=(int*)malloc(list1->counts*sizeof(int));
    printf("Please input %d number:",list1->counts);
    fill_list(list1);
    printf("Please enter how many numbers in list2:");
    scanf("%d",&list2->counts);
    list2->p_list=(int*)malloc(list2->counts*sizeof(int));
    printf("Please input %d number:",list2->counts);
    fill_list(list2);

    bubble_sort(list1);
    printf("sorted list1:");
    print_list(list1);
    printf("\n");
    bubble_sort(list2);
    printf("sorted list2:");
    print_list(list2);
    printf("\n");

    merge(list1,list2);



    return 0;
}