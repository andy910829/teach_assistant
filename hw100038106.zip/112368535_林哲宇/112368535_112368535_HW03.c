#include <stdio.h>
#include <stdlib.h>

typedef struct num_list {
    int counts;
    int *p_list;
} tNumList;

void fill_list(tNumList *list) {
    int i;

    printf("Please enter how many numbers in list: ");
    scanf_s("%d", &list->counts);

    list->p_list = (int *)malloc(list->counts * sizeof(int));
    printf("Please input %d numbers: ", list->counts);
    for (i = 0; i < list->counts; i++) {
        scanf_s("%d", &list->p_list[i]);
    }
}

void bubble_sort(tNumList *list) {
    int i, j, temp;

    for (i = 0; i < list->counts - 1; i++) {
        for (j = 0; j < list->counts - 1 - i; j++) {
            if (list->p_list[j] > list->p_list[j + 1]) {
                temp = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = temp;
            }
        }
    }
}

void print_list(tNumList *list) {
    int i;
    for (i = 0; i < list->counts; i++) {
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
}

void merge(tNumList *list1, tNumList *list2) {
    int i = 0, j = 0;

    printf("merged list: ");
    while (i < list1->counts && j < list2->counts) {
        if (list1->p_list[i] <= list2->p_list[j]) {
            printf("%d ", list1->p_list[i]);
            i++;
        } else {
            printf("%d ", list2->p_list[j]);
            j++;
        }
    }
    while (i < list1->counts) {
        printf("%d ", list1->p_list[i]);
        i++;
    }
    while (j < list2->counts) {
        printf("%d ", list2->p_list[j]);
        j++;
    }
    printf("\n");
}

int main(void) {
    tNumList *list1, *list2;

    list1 = (tNumList *)malloc(sizeof(tNumList));
    list2 = (tNumList *)malloc(sizeof(tNumList));

    fill_list(list1);
    fill_list(list2);

    bubble_sort(list1);
    bubble_sort(list2);

    printf("sorted list1: ");
    print_list(list1);

    printf("sorted list2: ");
    print_list(list2);

    merge(list1, list2);

    free(list1->p_list);
    free(list2->p_list);
    free(list1);
    free(list2);

    system("pause");
    return 0;
}