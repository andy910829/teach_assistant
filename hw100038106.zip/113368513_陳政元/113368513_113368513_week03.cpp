/*
Name: Chen Cheng Yuan
Student ID: 113368513
Date: 2025-09-25
File name: 113368513_week03.cpp
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
    int counts;
    int *p_list;
} tNumList;

void fill_list(tNumList *list);
void bubble_sort(tNumList *list);
void merge(tNumList *list1, tNumList *list2);
void print_list(tNumList *list);

int main(void)
{
    tNumList *list1, *list2;
    list1 = (tNumList *)malloc(sizeof(tNumList));
    list2 = (tNumList *)malloc(sizeof(tNumList));

    fill_list(list1);
    fill_list(list2);

    bubble_sort(list1);
    bubble_sort(list2);

    printf("sorted list1: ");
    print_list(list1);

    printf("sorted list2: ");
    print_list(list2);

    printf("merged list: ");
    merge(list1, list2);
    printf("\n");

    free(list1->p_list);
    free(list2->p_list);
    free(list1);
    free(list2);
    return 0;
}

void fill_list(tNumList *list)
{
    static int which = 1;
    int n;

    if (which == 1)
        printf("Please enter how many numbers in list1: ");
    else
        printf("Please enter how many numbers in list2: ");
    scanf("%d", &n);

    list->counts = n;
    list->p_list = (int *)malloc(sizeof(int) * n);

    printf("Please input %d numbers: ", n);
    for (int i = 0; i < n; ++i) {
        scanf("%d", &list->p_list[i]);
    }

    ++which;
}

void bubble_sort(tNumList *list)
{
    int n = list->counts;
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - 1 - i; ++j) {
            if (list->p_list[j] > list->p_list[j + 1]) {
                int tmp = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = tmp;
            }
        }
    }
}

void print_list(tNumList *list)
{
    for (int i = 0; i < list->counts; ++i) {
        if (i) printf(" ");
        printf("%d", list->p_list[i]);
    }
    printf("\n");
}

void merge(tNumList *list1, tNumList *list2)
{
    int i = 0, j = 0;

    while (i < list1->counts && j < list2->counts) {
        if (list1->p_list[i] < list2->p_list[j]) {
            printf("%d ", list1->p_list[i]);
            ++i;
        } else if (list2->p_list[j] < list1->p_list[i]) {
            printf("%d ", list2->p_list[j]);
            ++j;
        } else {
            printf("%d %d ", list1->p_list[i], list2->p_list[j]);
            ++i;
            ++j;
        }
    }
    while (i < list1->counts) {
        printf("%d ", list1->p_list[i]);
        ++i;
    }
    while (j < list2->counts) {
        printf("%d ", list2->p_list[j]);
        ++j;
    }
}
