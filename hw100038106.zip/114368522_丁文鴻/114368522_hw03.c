#include <stdio.h>   // 提供輸入輸出功能，如 printf, scanf
#include <stdlib.h>  // 提供動態記憶體配置，如 malloc, free

// 定義一個結構 num_list，用來存放數字清單
typedef struct num_list {
    int counts;    // 清單中數字的個數
    int *p_list;   // 指向整數陣列的指標（動態配置）
} tNumList;

// 函式宣告
void fill_list(tNumList *list);        // 輸入清單內容
void bubble_sort(tNumList *list);      // 使用冒泡排序
void merge(tNumList *list1 , tNumList *list2); // 合併兩個已排序清單
void print_list(tNumList *list);       // 印出清單內容

// 輸入清單函式
void fill_list(tNumList *list) {
    // 配置記憶體，能存放 counts 個 int
    list->p_list = (int*)malloc(sizeof(int) * list->counts);

    // 逐個讀入整數存入陣列
    for (int i = 0; i < list->counts; i++) {
        scanf("%d", &list->p_list[i]);
    }
}

// 冒泡排序函式（升冪排序）
void bubble_sort(tNumList *list) {
    for (int i = 0; i < list->counts - 1; i++) {
        for (int j = 0; j < list->counts - i - 1; j++) {
            if (list->p_list[j] > list->p_list[j + 1]) {
                // 交換相鄰元素
                int temp = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = temp;
            }
        }
    }
}

// 合併兩個排序好的清單，結果放回 list1
void merge(tNumList *list1, tNumList *list2) {
    int n1 = list1->counts;  // list1 的長度
    int n2 = list2->counts;  // list2 的長度
    int i = 0, j = 0, k = 0; // i, j 是索引，k 是合併後的位置

    // 配置新的陣列來存放合併後的結果
    int *merged = (int*)malloc(sizeof(int) * (n1 + n2));

    // 同步比較兩個清單，選擇較小者放進 merged
    while (i < n1 && j < n2) {
        if (list1->p_list[i] < list2->p_list[j]) {
            merged[k++] = list1->p_list[i++];
        } else {
            merged[k++] = list2->p_list[j++];
        }
    }

    // 若 list1 還有剩餘元素，依序放入 merged
    while (i < n1) merged[k++] = list1->p_list[i++];
    // 若 list2 還有剩餘元素，依序放入 merged
    while (j < n2) merged[k++] = list2->p_list[j++];

    // 釋放 list1 舊的陣列，避免記憶體洩漏
    free(list1->p_list);

    // 更新 list1，使其指向合併後的新陣列
    list1->p_list = merged;
    list1->counts = n1 + n2; // 更新元素數量
}

// 列印清單內容
void print_list(tNumList *list) {
    for (int i = 0; i < list->counts; i++) {
        printf("%d ", list->p_list[i]); // 印出每個數字
    }
    printf("\n"); // 換行
}

// 主程式入口
int main() {
    tNumList list1, list2;  // 建立兩個數字清單

    // 輸入 list1
    printf("Please enter how many numbers in list1: ");
    scanf("%d", &list1.counts);  // 讀取 list1 的數量
    printf("Please input %d numbers: ", list1.counts);
    fill_list(&list1);           // 輸入 list1 的數字

    // 輸入 list2
    printf("Please enter how many numbers in list2: ");
    scanf("%d", &list2.counts);  // 讀取 list2 的數量
    printf("Please input %d numbers: ", list2.counts);
    fill_list(&list2);           // 輸入 list2 的數字

    // 各自排序
    bubble_sort(&list1);
    bubble_sort(&list2);

    // 輸出排序後的清單
    printf("\nsorted list1: ");
    print_list(&list1);
    printf("sorted list2: ");
    print_list(&list2);

    // 合併兩個排序好的清單
    merge(&list1, &list2);

    // 輸出合併後的清單
    printf("merged list: ");
    print_list(&list1);

    // 釋放動態記憶體
    free(list1.p_list);
    free(list2.p_list);

    return 0; // 程式結束
}