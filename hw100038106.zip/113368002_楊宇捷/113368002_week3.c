#include <stdio.h>
#include <stdlib.h>

typedef struct numlist {
    int counts;
    int *p_list;
} tNumlist;

void fill_list(tNumlist *list);
void bubble_sort(tNumlist *list);
void merge_sort(tNumlist *list1 , tNumlist *list2);
void print_list(tNumlist *list);

int main(void)
{
    tNumlist *list1, *list2;
    list1 = (tNumlist *)malloc(sizeof(tNumlist));
    list2 = (tNumlist *)malloc(sizeof(tNumlist));

    printf("Please enter how many numbers in list1: ");
    scanf("%d", &list1->counts);
    printf("\tPlease input %d numbers: ", list1->counts);
    fill_list(list1);

    printf("Please enter how many numbers in list2: ");
    scanf("%d", &list2->counts);
    printf("\tPlease input %d numbers: ", list2->counts);
    fill_list(list2);

    printf("sorted list1: ");
    bubble_sort(list1);
    print_list(list1);
    printf("sorted list2: ");
    bubble_sort(list2);
    print_list(list2);

    printf("merged list: ");
    merge_sort(list1, list2);

    return 0;
}


void fill_list(tNumlist *list)
{
    int i;
    list->p_list = (int *)malloc(list->counts * sizeof(int));
    for(i = 0; i < list->counts; i++)
    {
        scanf("%d", (list->p_list + i) );
    }
}

void bubble_sort(tNumlist *list)
{
    int i, j, temp;
    for(i = 0; i < list->counts - 1; i++)
    {
        for(j = 0; j < list->counts - 1 - i; j++)
        {
            if(*(list -> p_list + j) > *(list -> p_list + j + 1))
            {
                temp = *(list -> p_list + j);
                *(list -> p_list + j) = *(list -> p_list + j + 1);
                *(list -> p_list + j + 1) = temp;
            }
        }
    }
}

void merge_sort(tNumlist *list1 , tNumlist *list2)
{
    int i = 0, j = 0;
    while(i < list1->counts || j < list2->counts)
    {
        if( *(list1->p_list +i) < *(list2-> p_list+j ) )
        {
            printf("%d ", *(list1 -> p_list + i) );
            i++;
        }
        else
        {
            printf("%d ", *(list2-> p_list + j) );
            j++;
        }
    }
}

void print_list(tNumlist *list)
{
    int i;
    for(i = 0; i < list->counts; i++)
    {
        printf("%d ", *(list->p_list+i));
    }
    printf("\r\n");
}