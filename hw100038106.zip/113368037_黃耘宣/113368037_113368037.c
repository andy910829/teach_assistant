#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
    int counts;
    int *p_list;
} tNumList;

void fill_list(tNumList *list)
{
    scanf("%d", &(list->counts));
    printf("Please input %d numbers:", list->counts);
    list->p_list = (int *)malloc(sizeof(int) * list->counts);
    for (int i = 0; i < list->counts; i++)
    {
        scanf("%d", &list->p_list[i]);
    }
}

void bubble_sort(tNumList *list)
{
    for (int i = 0; i < list->counts - 1; i++)
    {
        for (int j = 0; j < list->counts - 1 - i; j++)
        {
            if (list->p_list[j] > list->p_list[j + 1])
            {
                int temp = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = temp;
            }
        }
    }
}

void merge(tNumList *list1, tNumList *list2)
{
    int i = 0, j = 0;
    printf("merged list:");
    while (i < list1->counts && j < list2->counts)
    {
        if (list1->p_list[i] <= list2->p_list[j])
        {
            printf("%d ", list1->p_list[i]);
            i++;
        }
        else
        {
            printf("%d ", list2->p_list[j]);
            j++;
        }
    }

    while (i < list1->counts)
    {
        printf("%d ", list1->p_list[i]);
        i++;
    }

    while (j < list2->counts)
    {
        printf("%d ", list2->p_list[j]);
        j++;
    }
}

void print_list(tNumList *list)
{
    for (int i = 0; i < list->counts; i++)
    {
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
}

int main()
{
    tNumList *list1, *list2;
    list1 = (tNumList *)malloc(sizeof(tNumList));
    list2 = (tNumList *)malloc(sizeof(tNumList));
    printf("Please enter how many numbers in list1:");
    fill_list(list1);
    bubble_sort(list1);
    printf("Please enter how many numbers in list2:");
    fill_list(list2);
    bubble_sort(list2);
    printf("sorted list1:");
    print_list(list1);
    printf("sorted list2:");
    print_list(list2);
    merge(list1, list2);
    free(list1->p_list);
    free(list2->p_list);
    free(list1);
    free(list2);
    return 0;
}