#include <stdio.h>
#include <stdlib.h>



typedef struct num_list {
    int counts;
    int *p_list; 
} tNumList;

void fill_list(tNumList *list);

void bubble_sort(tNumList *list);

void merge(tNumList *list1, tNumList *list2);

void print_list(tNumList *list);

/**
 * @brief main function
 *
 * @file 2025_week03_assignment_solution.c
 * @date 2025/09/25
 * 
 * @param argc number of arguments
 * @param argv arguments
 * @return int 0 if success, 1 if error
 */
int main(int argc, char *argv[]) {



    // 先宣告
    tNumList *list1, *list2;

    // memory 分配一下
    list1 = (tNumList *)malloc(sizeof(tNumList));
    list2 = (tNumList *)malloc(sizeof(tNumList));

    // 填充第一個列表
    printf("Please enter how many numbers in list1: ");
    fill_list(list1);
    
    // 填充第二個列表
    printf("Please enter how many numbers in list2: ");
    fill_list(list2);


    // bublle sort list 1
    bubble_sort(list1);
    bubble_sort(list2);

    printf("\n");
    printf("sorted list1: ");
    print_list(list1);
    
    printf("\n");

    printf("sorted list2: ");
    print_list(list2);


    printf("\n");
    printf("merged list: ");
    merge(list1, list2);
    
    return 0;
}

void fill_list(tNumList *list)
{
    // 讀取數字個數
    scanf("%d", &(list->counts));
   
    // memory 分配
    list->p_list = (int *)malloc(list->counts * sizeof(int));
    
    // fill list
    printf("  Please input %d numbers: ", list->counts);
    for (int i = 0; i < list->counts; i++) {
        scanf("%d", &(list->p_list[i]));
        // printf("%d ", list->p_list[i]); // debug
    }
}

void bubble_sort(tNumList *list) {
    int length = list->counts;
    for (int i = 0; i < length - 1; i++) {
      for (int j = 0; j < length - i - 1; j++) {
        // if a[j] > a[j+1] then swap 
        if (list->p_list[j] > list->p_list[j + 1]) {
            int temp = list->p_list[j];
            list->p_list[j] = list->p_list[j + 1];
            list->p_list[j + 1] = temp;
        }
      }
    }
}

void print_list(tNumList *list) {
    int length = list->counts;
    for(int i = 0; i < length; i++) {
      printf("%d ", list->p_list[i]);
    }
}

void merge(tNumList *list1, tNumList *list2) {

  int i = 0;
  int j = 0;

  while (i < list1->counts && j < list2->counts) {
    if (list1->p_list[i] <= list2->p_list[j]) {
      printf("%d ", list1->p_list[i]);
      i++;
    } else {
      printf("%d ", list2->p_list[j]);
      j++;
    }
  }


  // print last list1 elements
  while (i <= list1->counts - 1) {
    printf("%d ", list1->p_list[i]);
    i++;
  }

  // print last list2 elemnts;
  while (j <= list2->counts - 1) {
    printf("%d ", list2->p_list[j]);
    j++;
  }

}
