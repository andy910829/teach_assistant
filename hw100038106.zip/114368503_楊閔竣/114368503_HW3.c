#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
	int counts;
	int *p_list;
}tNumList;

void fill_list(tNumList *list);
void bubble_sort(tNumList *list);
void merge(tNumList *list1,tNumList *list2);
void print_list(tNumList *list);

//不需要開新的list,在merge裡面找方法輪巡兩個list交替印出來就好
int main(int argc,char *argv[])
{
	tNumList list1,list2;
	printf("Please enter how many numbers in list1:\n");
	scanf("%d",&list1.counts);
	fill_list(&list1);
	bubble_sort(&list1);
	
	printf("\nPlease enter how many numbers in list2:\n");
	scanf("%d",&list2.counts);
	fill_list(&list2);
	bubble_sort(&list2);
	
	printf("\n===Merged===\n");
	merge(&list1,&list2);
}

void fill_list(tNumList *list)
{
	printf("\nPlease input %d numbers:\n",list->counts);
	list->p_list = (int*)malloc(sizeof(int)*(list->counts));
	int i;
	for(i=0; i < (list->counts); i++)
	{
		scanf("%d",&(list->p_list[i]));
	}
	print_list(list);
}
void print_list(tNumList *list)
{
	printf("\n===PrintList===\n");
	int i;
	for(i=0; i < (list->counts); i++)
	{
		printf("%d ",list->p_list[i]);
	}
}

void bubble_sort(tNumList *list) 
{
  int n = list->counts;
  int *arr = list->p_list;
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < i; ++j) {
      if (arr[j] > arr[i]) {
        int temp = arr[j];
        arr[j] = arr[i];
        arr[i] = temp;
      }
    }
  }
  print_list(list);
}

void merge(tNumList *list1,tNumList *list2)
{
	int i,i1,i2;
	int *ptr1 = list1->p_list;
	int *ptr2 = list2->p_list;
	i1 = list1->counts;
	i2 = list2->counts;
	
	while(i1>0 || i2>0)
	{
		//當list1印完時,只印list2就好,反之亦然
		if(i1==0)
		{
			printf("%d ",*ptr2);
			ptr2++;
			i2--;
		}
		else if(i2==0)//else是必須的否則兩數列最後一個數字來自i1並印完時,i2會多印一次
		{
			printf("%d ",*ptr1);
			ptr1++;
			i1--;
		}
		
		//list1當前指到數字比較小就印出來,並且遞增list1的指標
		if(*ptr1 <= *ptr2)
		{
			if(i1>0)
			{
				printf("%d ",*ptr1);
				ptr1++;
				i1--;
			}
		}
		//list2當前指到數字比較小就印出來,並且遞增list2的指標
		if(*ptr1 > *ptr2)
		{	
			if(i2>0)
			{
				printf("%d ",*ptr2);
				ptr2++;
				i2--;
			}
		}
	}
	
}