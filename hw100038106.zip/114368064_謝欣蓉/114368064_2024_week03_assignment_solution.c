#include <stdio.h>
#include <stdlib.h>

typedef struct num_list 
{
    int counts;//list中的數字總數
    int *p_list;//指向整數陣列的指標，用來儲存數字
} tNumList;

void fill_list(tNumList *list, int num) 
{
    printf("Please enter how many numbers in list%d: ",num);
    scanf("%d", &list->counts);
    
    list->p_list = (int *) malloc(list->counts * sizeof(int));
    if (list->p_list == NULL) 
    {
    printf("Memory allocation failed \n");
    exit(1); 
    }

    printf("    Please input %d numbers: ", list->counts);
    for (int i = 0; i < list->counts; i++) //存入分配好的記憶體中
    {
        scanf("%d", &list->p_list[i]);
    }
}

void bubble_sort(tNumList *list) 
{
    int i, j, temp;
    int n = list->counts;
    for (i = 0; i < n - 1; i++) 
    {
        for (j = 0; j < n - i - 1; j++) 
        {
            if (list->p_list[j] > list->p_list[j + 1]) 
            {
                temp = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = temp;
            }
        }
    }
}

void merge(tNumList *list1, tNumList *list2) 
{
    int i = 0; //list1 的index
    int j = 0; //list2 的index

    // 當兩個都還有元素時，比較並印出較小者
    while (i < list1->counts && j < list2->counts) 
    {
        if (list1->p_list[i] < list2->p_list[j]) 
        {
            printf("%d ", list1->p_list[i]);
            i++;
        } else 
        {
            printf("%d ", list2->p_list[j]);
            j++;
        }
    }

    // if list1 還有元素，全部印出
    while (i < list1->counts) {
        printf("%d ", list1->p_list[i]);
        i++;
    }

    // if list2 還有剩餘元素，全部印出
    while (j < list2->counts) {
        printf("%d ", list2->p_list[j]);
        j++;
    }
    
    printf("\n");
}

void print_list(tNumList *list) 
{
    for (int i = 0; i < list->counts; i++) 
    {
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
}

int main(void) 
{
    tNumList *list1, *list2;
    list1 = (tNumList *) malloc (sizeof(tNumList));
    list2 = (tNumList *) malloc (sizeof(tNumList));
    if (list1 == NULL) 
    {
    printf("Memory allocation failed \n");
    exit(1);
    }

    fill_list(list1, 1);
    fill_list(list2, 2);

    bubble_sort(list1);
    printf("\n");
    printf("\n");
    printf("sorted list1: ");
    print_list(list1);

    bubble_sort(list2);
    printf("sorted list2: ");
    print_list(list2);

    printf("merged list: ");
    merge(list1, list2);
    
    free(list1->p_list);
    free(list2->p_list);
    
    free(list1);
    free(list2);

    return 0;
}