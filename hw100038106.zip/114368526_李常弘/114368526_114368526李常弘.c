#include <stdio.h>
#include <stdlib.h>


typedef struct num_list{
    int counts;
    int *p_list;
} tNumList;

void fill_list (tNumList *list) {
    int count;
    scanf("%d", &count);
    list->counts = count;
    list->p_list = (int *) malloc(sizeof(int) * count);
    printf("\tPlease input %d numbers: ", count);
    for (int i = 0; i < count; i++){
        scanf("%d", &list->p_list[i]);
    }
};
void bubble_sort (tNumList *list){
    // 排序
    for (int i = 0; i < list->counts - 1; i++) {
        for (int j = 0; j < list->counts - i - 1; j++) {
            if (list->p_list[j] > list->p_list[j+1]) {
                int tmp = list->p_list[j];
                list->p_list[j] = list->p_list[j+1];
                list->p_list[j+1] = tmp;
            }
        }
    }
};
void merge (tNumList *list1, tNumList *list2){
    // 結合兩個list但不儲存在新的list，也不更動舊的
    // 輪流比較兩個已經排序過的指標陣列，小的就印出且指標後移
    int i = 0, j = 0;
    printf("Merged result: ");
    while (i < list1->counts && j < list2->counts) {
        if (list1->p_list[i] <= list2->p_list[j]) {
            printf("%d ", list1->p_list[i++]);
        } else {
            printf("%d ", list2->p_list[j++]);
        }
    }
    while (i < list1->counts) printf("%d ", list1->p_list[i++]);
    while (j < list2->counts) printf("%d ", list2->p_list[j++]);
    printf("\n");
};
void print_list (tNumList *list){
    for (int i=0; i< list->counts;i++) {
        printf("%d ", list->p_list[i]);
    }
    printf("\n");
};

int main() {
    tNumList *list1, *list2;
    list1 = (tNumList *) malloc(sizeof(tNumList));
    list2 = (tNumList *) malloc(sizeof(tNumList));

    printf("Please enter how many numbers in list1: ");
    fill_list(list1);
    printf("Please enter how many numbers in list2: ");
    fill_list(list2);

    bubble_sort(list1);
    printf("sorted list%d: ", 1);
    print_list(list1);

    bubble_sort(list2);
    printf("sorted list%d: ", 2);
    print_list(list2);

    merge(list1,list2);

    free(list1->p_list);
    free(list2->p_list);
    free(list1);
    free(list2);

    return 0;
}
