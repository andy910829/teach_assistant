#include <stdio.h>
#include <stdlib.h>

typedef struct num_list
{
    int counts;
    int *p_list;
}tNumList;

void fill_list(tNumList *list);
void bubble_sort(tNumList *list);
void merge(tNumList *list1,tNumList *list2);
void print_list(tNumList *list);

void fill_list(tNumList *list) {
    static int call_idx = 0;                 //0→list1, 1→list2 
    const char *name = (call_idx == 0) ? "list1" : "list2";
    call_idx++;

    int n;
    
    printf("Please enter how many numbers in %s: ", name);
    scanf("%d",&n);
    list->counts = n;                                     
    list->p_list = (int*)malloc(sizeof(int)*n);
    printf("Please input %d numbers: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d",&list->p_list[i]);
    }
}
void bubble_sort(tNumList *list) {
    int n = list->counts;
    for (int i = 0; i < n - 1; i++) {
        int swapped = 0;
        for (int j = 0; j < n - 1 - i; j++) {
            if (list->p_list[j] > list->p_list[j + 1]) {
                int t = list->p_list[j];
                list->p_list[j] = list->p_list[j + 1];
                list->p_list[j + 1] = t;
                swapped = 1;
            }
        }
        if (!swapped) break;
    }
}
void print_list(tNumList *list) {
    for (int i = 0; i < list->counts; i++) {
        if (i) 
            printf(" ");
        printf("%d", list->p_list[i]);
    }
    printf("\n");
}
void merge(tNumList *list1, tNumList *list2) {
    int i = 0, j = 0;                         //2
    int n1 = list1 ? list1->counts : 0;
    int n2 = list2 ? list2->counts : 0;

    printf("merged list: ");
    int first = 1;                             //space
    while (i < n1 && j < n2) {
        int x;
        if (list1->p_list[i] <= list2->p_list[j]) {
            x = list1->p_list[i++];
        } else {
            x = list2->p_list[j++];
        }
        if (!first) 
            printf(" ");
        printf("%d", x);
        first = 0;
    }
    while (i < n1) {
        if (!first) 
            printf(" ");
        printf("%d", list1->p_list[i++]);
        first = 0;
    }
    while (j < n2) {
        if (!first) 
            printf(" ");
        printf("%d", list2->p_list[j++]);
        first = 0;
    }
    printf("\n");
}
int main(){
    tNumList *list1, *list2;
    list1 = (tNumList*) malloc(sizeof(tNumList));
    list2 = (tNumList*) malloc(sizeof(tNumList));

    fill_list(list1);
    fill_list(list2);

    bubble_sort(list1);                        
    bubble_sort(list2);

    printf("sorted list1: ");
    print_list(list1);
    printf("sorted list2: ");
    print_list(list2);

    
    merge(list1, list2);

    //free
    free(list1->p_list);
    free(list2->p_list);
    free(list1);
    free(list2);
    return 0;
}