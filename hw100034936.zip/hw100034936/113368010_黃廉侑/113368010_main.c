#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    CHT,
    FET,
    TWN
} Operator;

typedef union {
    struct {
        char areaCode[5]; // �ϰ�X (�̦h4�Ӧr��)
        char number[10];   // �a�x�q�ܸ��X
    } home;
    struct {
        Operator operator; // �q�H�~��
        char number[10];   // ��ʹq�ܸ��X
    } cellular;
} PhoneNumber;

typedef struct User {
    char name[10];         // �m�W
    PhoneNumber phone;     // �q�ܸ��X
    struct User* next;     // ���V�U�@�ӥΤ᪺���w
} User;

void addUser(User** head) {
    User* newUser = (User*)malloc(sizeof(User));
    
    printf("Please enter the name: ");
    scanf("%s", newUser->name);
    
    int type;
    printf("Please select phone type (1: Home, 2: Cellular): ");
    scanf("%d", &type);
    
    if (type == 1) {
        printf("Please enter the area code: ");
        scanf("%4s", newUser->phone.home.areaCode); // �����J����
        printf("Please enter the home phone number: ");
        scanf("%9s", newUser->phone.home.number); // �����J����
        
    } else if (type == 2) {
        int op;
        printf("Please select telecom operator (0: CHT, 1: FET, 2: TWN): ");
        scanf("%d", &op);
        newUser->phone.cellular.operator = op;
        printf("Please enter the cellular phone number: ");
        scanf("%9s", newUser->phone.cellular.number); // �����J����
        newUser->phone.home.areaCode[0] = 0; // �L��ʹq�ܰϰ�X
    }
    
    newUser->next = *head;
    *head = newUser;
}

void printUsers(User* head) {
    User* current = head;
    while (current != NULL) {
        printf("Name: %s\n", current->name);
        
        if (current->phone.home.areaCode[0] != '\0') { // �a�x�q��
            printf("Home Phone: (%s) %s\n", current->phone.home.areaCode, current->phone.home.number);
        } else { // ��ʹq��
            char* operators[] = {"CHT", "FET", "TWN"};
            printf("Cellular Phone (%s): %s\n", operators[current->phone.cellular.operator], current->phone.cellular.number);
        }
        
        current = current->next;
    }
}

int main() {
    User* userList = NULL;
    
    char choice;
    do {
        addUser(&userList);
        
        printf("Would you like to add another user? (y/n): ");
        scanf(" %c", &choice); // �`�N�Ů�H���L�����
    } while (choice == 'y');
    
    printf("\nAll user information:\n");
    printUsers(userList);
    
    // ����O����
    User* temp;
    while (userList != NULL) {
        temp = userList;
        userList = userList->next;
        free(temp);
    }
    
    return 0;
}