/*
student id: 113368017
student name: ���G�j
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Enum for cellular operators
typedef enum {
    CHT, FET, TWN // 0, 1, 2
} Operator;

// Union for phone number
typedef union {
    struct {
        char areaCode[3];
        char number[8];
    } home;
    struct {
        Operator operator;
        char number[11];
    } cellular;
} PhoneNumber;

// Struct for linked list node
typedef struct Node {
    char name[10];
    int isCellular; // 1 for cellular, 0 for home
    PhoneNumber phone;
    struct Node* next;
} Node;

typedef struct NodeList {
    Node *head;
    Node *tail;
    int count;
} NodeList;

// Function to create a new node
Node* createNode(const char* name, int isCellular, PhoneNumber phone) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    strcpy(newNode->name, name);
    newNode->isCellular = isCellular;
    newNode->phone = phone;
    newNode->next = NULL;
    return newNode;
}

// Function to initialize a NodeList
void initNodeList(NodeList* list) {
    list->head = NULL;
    list->tail = NULL;
    list->count = 0;
}

// Function to add a node to the linked list
void addNode(NodeList* list, Node* newNode) {
    if (list->head == NULL) {
        list->head = newNode;
        list->tail = newNode;
    } else {
        list->tail->next = newNode;
        list->tail = newNode;
    }
    list->count++;
}

// Function to print the list
void printList(NodeList* list) {
    Node* temp = list->head;
    while (temp) {
        printf("Name: %s\n", temp->name);
        if (temp->isCellular) {
            printf("Cellular Operator: %s\n",
                temp->phone.cellular.operator == CHT ? "CHT" :
                temp->phone.cellular.operator == FET ? "FET" : "TWN");
            printf("Number: %s\n", temp->phone.cellular.number);
        } else {
            printf("Home Area Code: %s\n", temp->phone.home.areaCode);
            printf("Number: %s\n", temp->phone.home.number);
        }
        printf("-------------------\n");
        temp = temp->next;
    }
}

// Main function
int main() {
    NodeList list;
    initNodeList(&list);
    int choice = 1;

    while (choice) {
        char name[10];
        int isCellular;
        PhoneNumber phone;

        printf("Enter Name (max 9 characters): ");
        scanf("%s", name);

        printf("Enter 1 for Cellular or 0 for Home: ");
        scanf("%d", &isCellular);

        if (isCellular) {
            int operatorChoice;
            printf("Enter Cellular Operator (0-CHT, 1-FET, 2-TWN): ");
            scanf("%d", &operatorChoice);
            phone.cellular.operator = (Operator)operatorChoice;
            printf("Enter Cellular Number: ");
            scanf("%s", phone.cellular.number);
        } else {
            printf("Enter Home Area Code (max 3 characters): ");
            scanf("%s", phone.home.areaCode);
            printf("Enter Home Number: ");
            scanf("%s", phone.home.number);
        }

        Node* newNode = createNode(name, isCellular, phone);
        addNode(&list, newNode);

        printf("Do you want to add another user? (1-Yes, 0-No): ");
        scanf("%d", &choice);
    }

    printf("\nAll Users:\n");
    printf("-------------------\n");
    printList(&list);

    // Free memory
    Node* temp;
    while (list.head) {
        temp = list.head;
        list.head = list.head->next;
        free(temp);
    }

    return 0;
}